"""AA SL 1.4 の図をつくる。

    python3 figs/aa-sl/make_aasl_1_4.py            … SVG だけ
    FIG_PNG=1 python3 figs/aa-sl/make_aasl_1_4.py  … 目視用の PNG も

出力: aa-sl/01-number-and-algebra/img/aasl-1-4-idea-a.svg
      aa-sl/01-number-and-algebra/img/aasl-1-4-idea-b.svg

(a) 単利はまっすぐ、複利は上に曲がる（$1000、年 10%）。
(b) k を大きくすると、1 回あたりの利率は小さく、回数は多くなる。

matplotlib の mathtext には次の制限があります（tools/README.md）。
  * \begin{pmatrix} は読めない → \binom を使う
  * \lvert \rvert は読めない → | を使う
  * 日本語のグリフがない → ラベルはすべて英語

★ 図に演習の答えを書かないこと。
★ PNG は目視用です。確認が終わったら消してください。
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "..", "aa-sl", "01-number-and-algebra", "img")
os.makedirs(OUT, exist_ok=True)

INK = "#1f2328"
ACCENT = "#0b5cad"
GREY = "#6b7280"
WARM = "#b45309"

fig1, ax1 = plt.subplots(figsize=(5.1, 4.0))
fig2, ax2 = plt.subplots(figsize=(5.1, 3.2))
# ══════════════════════════════════════════════════════════
# (a) 単利と複利（$1000、年 10%、10 年）
# ══════════════════════════════════════════════════════════
YEARS = list(range(0, 11))
SIMPLE = [1000 + 100 * n for n in YEARS]
COMP = [1000 * 1.1 ** n for n in YEARS]

ax1.plot(YEARS, SIMPLE, marker="o", markersize=4, color=GREY, linewidth=1.6,
         label="simple interest")
ax1.plot(YEARS, COMP, marker="o", markersize=4, color=ACCENT, linewidth=1.8,
         label="compound interest")
ax1.set_xlabel("years", fontsize=10, color=INK)
ax1.set_ylabel("value (\\$)", fontsize=10, color=INK)
ax1.set_xticks(range(0, 11, 2))
ax1.set_yticks([1000, 1500, 2000, 2500])
ax1.tick_params(labelsize=9, colors=INK)
for side in ("top", "right"):
    ax1.spines[side].set_visible(False)
for side in ("left", "bottom"):
    ax1.spines[side].set_color(INK)
ax1.grid(axis="y", color="#e5e7eb", linewidth=0.8)
ax1.set_axisbelow(True)
ax1.legend(fontsize=9.5, frameon=False, loc="upper left")

# ══════════════════════════════════════════════════════════
# (b) k を変えると、1 回あたりの利率と回数の両方が変わる
# ══════════════════════════════════════════════════════════
ax2.set_xlim(-0.1, 1.32)
ax2.set_ylim(0.2, 3.25)
ax2.axis("off")

# 1 期あたりの倍率は、12% を k 等分したもの
ROWS = [(2.7, 1, "$k=1$", "$\\times 1.12$", "once"),
        (1.6, 2, "$k=2$", "$\\times 1.06$", "twice"),
        (0.5, 4, "$k=4$", "$\\times 1.03$", "four times")]
for y, k, klab, fac, note in ROWS:
    ax2.plot([0.0, 1.0], [y, y], color=INK, linewidth=1.4)
    for j in range(k + 1):
        x = j / k
        ax2.plot([x, x], [y - 0.12, y + 0.12], color=INK, linewidth=1.2)
    for j in range(k):
        ax2.text((j + 0.5) / k, y + 0.20, fac, ha="center", va="bottom",
                 fontsize=9.5 if k < 4 else 8.5, color=ACCENT)
    ax2.text(-0.06, y, klab, ha="right", va="center", fontsize=11, color=INK)
    ax2.text(1.06, y, note, ha="left", va="center", fontsize=9.5, color=WARM)


for _fig, _name in ((fig1, "aasl-1-4-idea-a.svg"), (fig2, "aasl-1-4-idea-b.svg")):
    _fig.tight_layout()
    _p = os.path.join(OUT, _name)
    _fig.savefig(_p, format="svg", bbox_inches="tight", transparent=True)
    print("wrote", os.path.normpath(_p))
    if os.environ.get("FIG_PNG"):
        _q = _p[:-4] + ".png"
        _fig.savefig(_q, format="png", dpi=150, bbox_inches="tight",
                     facecolor="white")
        print("wrote", os.path.normpath(_q))
