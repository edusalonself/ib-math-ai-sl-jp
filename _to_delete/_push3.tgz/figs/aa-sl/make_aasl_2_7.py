"""AA SL 2.7 の図をつくる（2.7a と 2.7b を結合したページ）。

    python3 figs/aa-sl/make_aasl_2_7.py            … SVG だけ
    FIG_PNG=1 python3 figs/aa-sl/make_aasl_2_7.py  … 目視用の PNG も

出力: aa-sl/02-functions/img/aasl-2-7-idea-a.svg
      aa-sl/02-functions/img/aasl-2-7-idea-b.svg
      aa-sl/02-functions/img/aasl-2-7-idea-c.svg
      aa-sl/02-functions/img/aasl-2-7-idea-d.svg

(a) 2 次方程式を解く 3 つの道すじ。
(b) 2 次不等式は、グラフが軸の上か下かで決まる。

matplotlib の mathtext には次の制限があります（tools/README.md）。
  * \\begin{pmatrix} は読めない → \\binom を使う
  * \\lvert \\rvert は読めない → | を使う
  * 日本語のグリフがない → ラベルはすべて英語

★ 図に演習の答えを書かないこと（具体的な数値は書かない）。
★ PNG は目視用です。確認が終わったら消してください。
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "..", "aa-sl", "02-functions", "img")
os.makedirs(OUT, exist_ok=True)

INK = "#1f2328"
ACCENT = "#0b5cad"
GREY = "#6b7280"
WARM = "#b45309"
GREEN = "#15803d"
PALE = "#e8f0f8"

fig1, ax1 = plt.subplots(figsize=(5.3, 3.6))
fig2, ax2 = plt.subplots(figsize=(5.3, 4.6))
fig3, ax3 = plt.subplots(figsize=(5.3, 4.6))
fig4, ax4 = plt.subplots(figsize=(5.3, 4.6))
# ══════════════════════════════════════════════════════════
# (a) 3 つの道すじ
# ══════════════════════════════════════════════════════════
ax1.set_xlim(0, 10)
ax1.set_ylim(1.9, 9.7)
ax1.axis("off")

ax1.add_patch(FancyBboxPatch((1.2, 8.0), 7.6, 1.4,
                             boxstyle="round,pad=0.06,rounding_size=0.2",
                             linewidth=1.6, edgecolor=INK, facecolor=PALE))
ax1.text(5.0, 8.7, "$ax^{2}+bx+c = 0$", ha="center", va="center",
         fontsize=12, color=INK)

routes = [
    (2.0, "factorising", ACCENT),
    (5.0, "completing\nthe square", GREEN),
    (8.0, "the quadratic\nformula", WARM),
]
for cx, name, col in routes:
    ax1.annotate("", xy=(cx, 6.4), xytext=(5.0, 7.9),
                 arrowprops=dict(arrowstyle="->", color=GREY, linewidth=1.2))
    ax1.add_patch(FancyBboxPatch((cx - 1.25, 4.9), 2.5, 1.5,
                                 boxstyle="round,pad=0.06,rounding_size=0.2",
                                 linewidth=1.6, edgecolor=col,
                                 facecolor="none"))
    ax1.text(cx, 5.65, name, ha="center", va="center", fontsize=11,
             color=col)

ax1.annotate("", xy=(5.0, 3.65), xytext=(2.0, 4.75),
             arrowprops=dict(arrowstyle="->", color=GREY, linewidth=1.2))
ax1.annotate("", xy=(5.0, 3.65), xytext=(5.0, 4.75),
             arrowprops=dict(arrowstyle="->", color=GREY, linewidth=1.2))
ax1.annotate("", xy=(5.0, 3.65), xytext=(8.0, 4.75),
             arrowprops=dict(arrowstyle="->", color=GREY, linewidth=1.2))
ax1.add_patch(FancyBboxPatch((2.6, 2.2), 4.8, 1.4,
                             boxstyle="round,pad=0.06,rounding_size=0.2",
                             linewidth=1.6, edgecolor=INK, facecolor=PALE))
ax1.text(5.0, 2.9, "the same solutions", ha="center", va="center",
         fontsize=12, color=INK)

# ══════════════════════════════════════════════════════════
# (b) 2 次不等式
# ══════════════════════════════════════════════════════════
ax2.set_xlim(-3.6, 4.6)
ax2.set_ylim(-3.0, 5.8)
ax2.axis("off")

ax2.annotate("", xy=(4.4, 0), xytext=(-3.4, 0),
             arrowprops=dict(arrowstyle="->", color=GREY, linewidth=1.1))
ax2.annotate("", xy=(0, 4.6), xytext=(0, -2.8),
             arrowprops=dict(arrowstyle="->", color=GREY, linewidth=1.1))
ax2.text(4.5, -0.36, "$x$", fontsize=11, color=GREY, ha="center")
ax2.text(-0.26, 4.7, "$y$", fontsize=11, color=GREY, va="center")

Pp, Qq = -1.6, 3.0


def _qy(z):
    return 0.55 * (z - Pp) * (z - Qq)


# 曲線そのものを、f(x) の符号で塗り分ける
for _a, _b, _col in ((-3.0, Pp, WARM), (Pp, Qq, GREEN), (Qq, 4.1, WARM)):
    _u = np.linspace(_a, _b, 200)
    ax2.plot(_u, _qy(_u), color=_col, linewidth=2.4)
for px in (Pp, Qq):
    ax2.plot([px], [0], marker="o", markersize=6, color=INK, zorder=3)

ax2.text(-3.45, 5.25, "$f(x) > 0$", fontsize=10, color=WARM,
         ha="left", va="center")
ax2.text(0.7, -1.95, "$f(x) < 0$", fontsize=10, color=GREEN,
         ha="center", va="center")
ax2.text(4.45, 3.95, "$f(x) > 0$", fontsize=10, color=WARM,
         ha="right", va="center")

# ══════════════════════════════════════════════════════════
# (c) 判別式の符号と交わる回数（第 6 節）
# ══════════════════════════════════════════════════════════
ax3.set_xlim(-1.2, 11.2)
ax3.set_ylim(-3.4, 4.6)
ax3.axis("off")

cases = [
    (1.6, -1.2, ACCENT, "$\\Delta > 0$", "two distinct\nreal roots"),
    (5.4, 0.0, GREEN, "$\\Delta = 0$", "two equal\nreal roots"),
    (9.2, 1.2, WARM, "$\\Delta < 0$", "no real\nroots"),
]
for cx, shift, col, lab, note in cases:
    ax3.plot([cx - 1.5, cx + 1.5], [0, 0], color=GREY, linewidth=1.0)
    t = np.linspace(-1.45, 1.45, 200)
    ax3.plot(cx + t, 1.35 * t ** 2 + shift, color=col, linewidth=2.2)
    if shift < 0:
        r = np.sqrt(-shift / 1.35)
        for sgn in (-1, 1):
            ax3.plot([cx + sgn * r], [0], marker="o", markersize=5.5,
                     color=INK, zorder=3)
    elif shift == 0:
        ax3.plot([cx], [0], marker="o", markersize=5.5, color=INK, zorder=3)
    ax3.text(cx, 3.6, lab, ha="center", va="center", fontsize=13, color=col)
    ax3.text(cx, -1.6, note, ha="center", va="top", fontsize=10, color=INK)

ax3.text(5.4, -3.3, "$\\Delta = b^{2} - 4ac$", ha="center", va="bottom",
         fontsize=12, color=INK)

# ══════════════════════════════════════════════════════════
# (b) 直線と曲線
# ══════════════════════════════════════════════════════════
ax4.set_xlim(-3.4, 3.4)
ax4.set_ylim(-3.0, 6.6)
ax4.axis("off")

ax4.annotate("", xy=(3.0, 0), xytext=(-2.6, 0),
             arrowprops=dict(arrowstyle="->", color=GREY, linewidth=1.1))
ax4.annotate("", xy=(0, 6.4), xytext=(0, -2.8),
             arrowprops=dict(arrowstyle="->", color=GREY, linewidth=1.1))
ax4.text(3.1, -0.34, "$x$", fontsize=11, color=GREY, ha="center")
ax4.text(-0.26, 6.5, "$y$", fontsize=11, color=GREY, va="center")

v = np.linspace(-2.2, 2.2, 200)
ax4.plot(v, v ** 2 + 1, color=ACCENT, linewidth=2.2)
ax4.plot(v, 2 * v + 2.6, color=WARM, linewidth=2.0)
ax4.plot(v, 2 * v + 0.0, color=GREEN, linewidth=2.0)
ax4.plot(v, 2 * v - 1.0, color=GREY, linewidth=2.0, linestyle=(0, (5, 4)))
ax4.plot([1.0], [2.0], marker="o", markersize=6, color=GREEN, zorder=3)

ax4.text(0.45, -0.80, "two points: $\\Delta > 0$", fontsize=10, color=WARM,
         ha="left", va="top")
ax4.text(0.45, -1.55, "tangent: $\\Delta = 0$", fontsize=10, color=GREEN,
         ha="left", va="top")
ax4.text(0.45, -2.30, "no point: $\\Delta < 0$", fontsize=10, color=GREY,
         ha="left", va="top")
ax4.text(-2.35, 6.45, "$y = f(x)$", fontsize=11, color=ACCENT,
         ha="left", va="top")
ax4.annotate("", xy=(1.0, 2.0), xytext=(1.9, 1.0),
             arrowprops=dict(arrowstyle="->", color=GREEN, linewidth=0.9))

for _fig, _name in ((fig1, "aasl-2-7-idea-a.svg"),
                    (fig2, "aasl-2-7-idea-b.svg"),
                    (fig3, "aasl-2-7-idea-c.svg"),
                    (fig4, "aasl-2-7-idea-d.svg")):
    _fig.tight_layout()
    _p = os.path.join(OUT, _name)
    _fig.savefig(_p, format="svg", bbox_inches="tight", transparent=True)
    print("wrote", os.path.normpath(_p))
    if os.environ.get("FIG_PNG"):
        _q = _p[:-4] + ".png"
        _fig.savefig(_q, format="png", dpi=150, bbox_inches="tight",
                     facecolor="white")
        print("wrote", os.path.normpath(_q))
