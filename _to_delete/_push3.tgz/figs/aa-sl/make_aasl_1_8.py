"""AA SL 1.8 の図をつくる。

    python3 figs/aa-sl/make_aasl_1_8.py            … SVG だけ
    FIG_PNG=1 python3 figs/aa-sl/make_aasl_1_8.py  … 目視用の PNG も

出力: aa-sl/01-number-and-algebra/img/aasl-1-8-idea-a.svg
      aa-sl/01-number-and-algebra/img/aasl-1-8-idea-b.svg

(a) 面積 1 の正方形を、毎回「残りの半分」で埋めていく。
    足しても正方形からはみ出さない ＝ 部分和が 1 を超えない。
(b) r の大きさで、項のふるまいが分かれる。
    |r| < 1 なら 0 に向かい、|r| > 1 なら大きくなる。

matplotlib の mathtext には次の制限があります（tools/README.md）。
  * \\begin{pmatrix} は読めない → \\binom を使う
  * \\lvert \\rvert は読めない → | を使う
  * 日本語のグリフがない → ラベルはすべて英語

★ 図に演習の答えを書かないこと。
★ PNG は目視用です。確認が終わったら消してください。
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "..", "aa-sl", "01-number-and-algebra", "img")
os.makedirs(OUT, exist_ok=True)

INK = "#1f2328"
ACCENT = "#0b5cad"
GREY = "#6b7280"
WARM = "#b45309"

fig1, ax1 = plt.subplots(figsize=(4.0, 4.0))
fig2, ax2 = plt.subplots(figsize=(5.0, 3.6))
# ══════════════════════════════════════════════════════════
# (a) 面積 1 の正方形を、半分ずつ埋めていく
# ══════════════════════════════════════════════════════════
ax1.set_xlim(-0.06, 1.06)
ax1.set_ylim(-0.06, 1.10)
ax1.set_aspect("equal")
ax1.axis("off")

#   1/2 : left half            1/4 : top right
#   1/8 : bottom, left of it   1/16, 1/32, ... spiral inwards
PIECES = [
    (0.0, 0.0, 0.5, 1.0, "#cfe3f7", r"$\frac{1}{2}$"),
    (0.5, 0.5, 0.5, 0.5, "#a9cdef", r"$\frac{1}{4}$"),
    (0.5, 0.0, 0.25, 0.5, "#83b7e7", r"$\frac{1}{8}$"),
    (0.75, 0.25, 0.25, 0.25, "#5da1df", None),
    (0.75, 0.0, 0.125, 0.25, "#4a93d6", None),
    (0.875, 0.125, 0.125, 0.125, "#3f8ace", None),
    (0.875, 0.0, 0.0625, 0.125, "#3782c7", None),
    (0.9375, 0.0625, 0.0625, 0.0625, "#2f78bd", None),
]
for _x, _y, _w, _h, _c, _lab in PIECES:
    ax1.fill_between([_x, _x + _w], _y, _y + _h, color=_c, linewidth=0)
    ax1.plot([_x, _x + _w, _x + _w, _x, _x],
             [_y, _y, _y + _h, _y + _h, _y], color="white", linewidth=1.0)
    if _lab:
        ax1.text(_x + _w / 2, _y + _h / 2, _lab, ha="center", va="center",
                 fontsize=13, color="#0b2f52")

ax1.plot([0, 1, 1, 0, 0], [0, 0, 1, 1, 0], color=INK, linewidth=1.4)
ax1.annotate("", xy=(1.0, 1.045), xytext=(0.0, 1.045),
             arrowprops=dict(arrowstyle="<->", color=WARM, linewidth=1.1))
ax1.text(0.5, 1.075, "$1$", ha="center", va="bottom", fontsize=11,
         color=WARM)

# ══════════════════════════════════════════════════════════
# (b) r の大きさで、項のふるまいが分かれる
# ══════════════════════════════════════════════════════════
NS = list(range(0, 6))
small = [0.5 ** k for k in NS]
big = [2.0 ** k for k in NS]

ax2.plot(NS, small, marker="o", markersize=5, color=ACCENT, linewidth=1.7,
         label="$r = 0.5$")
ax2.plot(NS, big, marker="o", markersize=5, color=WARM, linewidth=1.7,
         label="$r = 2$")
ax2.set_ylim(-0.35, 4.4)
ax2.set_xlim(-0.25, 5.6)
ax2.set_xticks(NS)
ax2.set_yticks([0, 1, 2, 3, 4])
ax2.set_xlabel("$n$", fontsize=10, color=INK)
ax2.set_ylabel("$r^{\\,n}$", fontsize=10, color=INK)
ax2.tick_params(labelsize=9, colors=INK)
for side in ("top", "right"):
    ax2.spines[side].set_visible(False)
for side in ("left", "bottom"):
    ax2.spines[side].set_color(INK)
ax2.grid(axis="y", color="#e5e7eb", linewidth=0.8)
ax2.set_axisbelow(True)
ax2.legend(fontsize=9.5, frameon=False, loc="upper left")
ax2.axhline(0.0, color=GREY, linewidth=1.0)
ax2.annotate("off the top", xy=(2.15, 4.15), xytext=(3.1, 3.6),
             fontsize=9.5, color=WARM,
             arrowprops=dict(arrowstyle="->", color=WARM, linewidth=1.0))

for _fig, _name in ((fig1, "aasl-1-8-idea-a.svg"), (fig2, "aasl-1-8-idea-b.svg")):
    _fig.tight_layout()
    _p = os.path.join(OUT, _name)
    _fig.savefig(_p, format="svg", bbox_inches="tight", transparent=True)
    print("wrote", os.path.normpath(_p))
    if os.environ.get("FIG_PNG"):
        _q = _p[:-4] + ".png"
        _fig.savefig(_q, format="png", dpi=150, bbox_inches="tight",
                     facecolor="white")
        print("wrote", os.path.normpath(_q))
