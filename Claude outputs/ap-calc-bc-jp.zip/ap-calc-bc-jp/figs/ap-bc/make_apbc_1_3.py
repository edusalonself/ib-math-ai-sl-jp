"""Unit 1.3（Continuity, discontinuities and the IVT）の図をつくる。

    python3 figs/ap-bc/make_apbc_1_3.py            … SVG だけ
    FIG_PNG=1 python3 figs/ap-bc/make_apbc_1_3.py  … 目視用の PNG も

出力: ap-bc/01-limits/img/apbc-1-3-idea-a.svg
      ap-bc/01-limits/img/apbc-1-3-idea-b.svg

(a) 不連続の 3 種類（removable / jump / vertical asymptote）。
(b) 中間値の定理。

matplotlib の mathtext には次の制限があります（tools/README.md）。
  * \\begin{pmatrix} は読めない → 使わない
  * \\lvert \\rvert も読めない → | を使う
  * 日本語のグリフがない → ラベルはすべて英語

★ 図に例題・演習の答えを書かないこと。
★ PNG は目視用です。確認が終わったら消してください。
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "..", "ap-bc", "01-limits", "img")
os.makedirs(OUT, exist_ok=True)

INK = "#1f2328"
ACCENT = "#0f766e"
GREY = "#6b7280"
WARM = "#b45309"
OLIVE = "#4d7c0f"

# ══════════════════════════════════════════════════════════
# (a) 不連続の 3 種類
# ══════════════════════════════════════════════════════════
fig1, axs = plt.subplots(1, 3, figsize=(7.6, 2.8))
fig1.suptitle("three types of discontinuity", fontsize=10.5, color=INK,
              x=0.02, ha="left")
axA, axB, axC = axs

# removable: 穴があいているだけ
tA = np.linspace(-1.4, 1.4, 300)
axA.plot(tA, tA + 2, color=ACCENT, linewidth=2.0)
axA.plot([0], [2], marker="o", markersize=7, markerfacecolor="white",
         markeredgecolor=ACCENT, markeredgewidth=1.6, zorder=5)
axA.set_title("removable", fontsize=9.5, color=GREY, pad=6)
axA.set_xlabel("the limit exists,\nbut the point is missing", fontsize=8.8,
               color=INK, labelpad=8)
axA.set_xlim(-1.7, 1.7)
axA.set_ylim(0.2, 3.8)

# jump: 左右がちがう
tB1 = np.linspace(-1.4, 0, 200)
tB2 = np.linspace(0, 1.4, 200)
axB.plot(tB1, 1.2 + 0 * tB1, color=WARM, linewidth=2.0)
axB.plot(tB2, 2.8 + 0 * tB2, color=WARM, linewidth=2.0)
axB.plot([0], [1.2], marker="o", markersize=7, markerfacecolor="white",
         markeredgecolor=WARM, markeredgewidth=1.6, zorder=5)
axB.plot([0], [2.8], marker="o", markersize=6, color=WARM, zorder=5)
axB.set_title("jump", fontsize=9.5, color=GREY, pad=6)
axB.set_xlabel("the two sides\ngo to different heights", fontsize=8.8,
               color=INK, labelpad=8)
axB.set_xlim(-1.7, 1.7)
axB.set_ylim(0.2, 3.8)

# vertical asymptote: 限りなく大きくなる
tC1 = np.linspace(-1.5, -0.22, 300)
tC2 = np.linspace(0.22, 1.5, 300)
axC.plot(tC1, 2 + 0.35 / tC1, color=OLIVE, linewidth=2.0)
axC.plot(tC2, 2 + 0.35 / tC2, color=OLIVE, linewidth=2.0)
axC.axvline(0, color=GREY, linewidth=1.0, linestyle=(0, (4, 3)))
axC.set_title("vertical asymptote", fontsize=9.5, color=GREY, pad=6)
axC.set_xlabel("the values become\nunbounded", fontsize=8.8, color=INK,
               labelpad=8)
axC.set_xlim(-1.7, 1.7)
axC.set_ylim(0.2, 3.8)

for _ax in axs:
    _ax.set_xticks([])
    _ax.set_yticks([])
    for _s in ("top", "right", "left", "bottom"):
        _ax.spines[_s].set_visible(False)

# ══════════════════════════════════════════════════════════
# (b) 中間値の定理
# ══════════════════════════════════════════════════════════
fig2, ax2 = plt.subplots(figsize=(5.8, 3.4))
ax2.set_title("a continuous graph cannot skip a height between $f(a)$ and $f(b)$",
              fontsize=10, color=INK, loc="left", pad=10)

u = np.linspace(1.0, 5.0, 500)
y = 0.9 + 0.62 * (u - 1) + 0.25 * np.sin(2.0 * (u - 1))
ax2.plot(u, y, color=ACCENT, linewidth=2.2, zorder=4)

d = 2.3
idx = np.where(np.diff(np.sign(y - d)))[0]
c = u[idx[0]]
ax2.plot([0.75, 5.35], [d, d], color=WARM, linewidth=1.1,
         linestyle=(0, (4, 3)), zorder=2)
ax2.plot([c, c], [0.35, d], color=GREY, linewidth=1.0,
         linestyle=(0, (4, 3)), zorder=2)
ax2.plot([c], [d], marker="o", markersize=6, color=WARM, zorder=6)
ax2.plot([1.0], [y[0]], marker="o", markersize=5.5, color=INK, zorder=6)
ax2.plot([5.0], [y[-1]], marker="o", markersize=5.5, color=INK, zorder=6)

ax2.text(5.45, d - 0.06, "$y = d$", fontsize=9.5, color=WARM)
ax2.text(0.82, y[0] - 0.33, "$f(a)$", fontsize=9.5, color=INK)
ax2.text(4.86, y[-1] + 0.16, "$f(b)$", fontsize=9.5, color=INK)
ax2.text(c - 0.06, 0.12, "$c$", fontsize=9.5, color=GREY)
ax2.text(0.95, 0.12, "$a$", fontsize=9.5, color=GREY)
ax2.text(4.95, 0.12, "$b$", fontsize=9.5, color=GREY)
ax2.text(1.0, 4.05, "$d$ is between $f(a)$ and $f(b)$, so $f(c) = d$"
         " for at least one $c$", fontsize=9, color=GREY)

ax2.set_xlim(0.55, 6.5)
ax2.set_ylim(0.0, 4.3)
ax2.set_xticks([])
ax2.set_yticks([])
for _s in ("top", "right", "left"):
    ax2.spines[_s].set_visible(False)
ax2.spines["bottom"].set_visible(False)

for _fig, _name in ((fig1, "a"), (fig2, "b")):
    _fig.tight_layout()
    _fig.savefig(os.path.join(OUT, "apbc-1-3-idea-%s.svg" % _name),
                 format="svg", bbox_inches="tight")
    if os.environ.get("FIG_PNG"):
        _fig.savefig(os.path.join(OUT, "apbc-1-3-idea-%s.png" % _name),
                     format="png", dpi=150, bbox_inches="tight")
print("wrote", OUT)
