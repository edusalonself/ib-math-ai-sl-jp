"""Unit 1.4（Infinite limits, limits at infinity and asymptotes）の図をつくる。

    python3 figs/ap-bc/make_apbc_1_4.py            … SVG だけ
    FIG_PNG=1 python3 figs/ap-bc/make_apbc_1_4.py  … 目視用の PNG も

出力: ap-bc/01-limits/img/apbc-1-4-idea-a.svg
      ap-bc/01-limits/img/apbc-1-4-idea-b.svg

(a) y = (2x+1)/(x-1)。垂直漸近線 x = 1 と水平漸近線 y = 2。
(b) 増え方の速さ。ln x < x^2 < e^x。

matplotlib の mathtext には次の制限があります（tools/README.md）。
  * \\begin{pmatrix} は読めない → 使わない
  * \\lvert \\rvert も読めない → | を使う
  * 日本語のグリフがない → ラベルはすべて英語

★ 図に例題・演習の答えを書かないこと。
★ PNG は目視用です。確認が終わったら消してください。
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "..", "ap-bc", "01-limits", "img")
os.makedirs(OUT, exist_ok=True)

INK = "#1f2328"
ACCENT = "#0f766e"
GREY = "#6b7280"
WARM = "#b45309"
OLIVE = "#4d7c0f"

# ══════════════════════════════════════════════════════════
# (a) 垂直漸近線と水平漸近線
# ══════════════════════════════════════════════════════════
fig1, ax1 = plt.subplots(figsize=(5.8, 3.6))
ax1.set_title("the graph hugs $x = 1$ and flattens towards $y = 2$",
              fontsize=10, color=INK, loc="left", pad=10)

tL = np.linspace(-5.0, 0.72, 500)
tR = np.linspace(1.28, 7.0, 500)
for _t in (tL, tR):
    ax1.plot(_t, (2 * _t + 1) / (_t - 1), color=ACCENT, linewidth=2.2, zorder=4)

ax1.axvline(1, color=WARM, linewidth=1.2, linestyle=(0, (4, 3)), zorder=2)
ax1.axhline(2, color=OLIVE, linewidth=1.2, linestyle=(0, (4, 3)), zorder=2)

ax1.text(1.15, -7.4, "$x = 1$", fontsize=9.5, color=WARM)
ax1.text(7.15, 2.15, "$y = 2$", fontsize=9.5, color=OLIVE)
ax1.text(3.1, 6.2, "$y = \\dfrac{2x+1}{x-1}$", fontsize=10, color=ACCENT)
ax1.text(-4.9, 4.6, "horizontal asymptote:\nthe end behaviour",
         fontsize=8.8, color=OLIVE)
ax1.text(-4.9, -6.9, "vertical asymptote:\nthe values blow up",
         fontsize=8.8, color=WARM)

ax1.set_xlim(-5.2, 9.2)
ax1.set_ylim(-8.0, 8.5)
ax1.set_xticks([1])
ax1.set_xticklabels(["$1$"])
ax1.set_yticks([2])
ax1.set_yticklabels(["$2$"])
ax1.spines["top"].set_visible(False)
ax1.spines["right"].set_visible(False)
ax1.tick_params(labelsize=9, colors=GREY)

# ══════════════════════════════════════════════════════════
# (b) 増え方の速さ
# ══════════════════════════════════════════════════════════
fig2, ax2 = plt.subplots(figsize=(5.8, 3.3))
ax2.set_title("for large $x$, the exponential runs away from the others",
              fontsize=10, color=INK, loc="left", pad=10)

u = np.linspace(0.25, 3.2, 600)
ax2.plot(u, np.exp(u), color=WARM, linewidth=2.0)
ax2.plot(u, u ** 2, color=ACCENT, linewidth=2.0)
ax2.plot(u, np.log(u), color=OLIVE, linewidth=2.0)

ax2.text(3.3, np.exp(3.2) - 1.0, "$y = e^{x}$", fontsize=9.5, color=WARM)
ax2.text(3.3, 3.2 ** 2 - 0.6, "$y = x^{2}$", fontsize=9.5, color=ACCENT)
ax2.text(3.3, np.log(3.2) - 0.5, "$y = \\ln x$", fontsize=9.5, color=OLIVE)

ax2.set_xlim(0.0, 4.6)
ax2.set_ylim(-2.0, 26.5)
ax2.set_xticks([1, 2, 3])
ax2.set_xticklabels(["$1$", "$2$", "$3$"])
ax2.set_yticks([])
ax2.axhline(0, color=GREY, linewidth=0.7, zorder=0)
ax2.spines["top"].set_visible(False)
ax2.spines["right"].set_visible(False)
ax2.spines["left"].set_visible(False)
ax2.tick_params(labelsize=9, colors=GREY)

for _fig, _name in ((fig1, "a"), (fig2, "b")):
    _fig.tight_layout()
    _fig.savefig(os.path.join(OUT, "apbc-1-4-idea-%s.svg" % _name),
                 format="svg", bbox_inches="tight")
    if os.environ.get("FIG_PNG"):
        _fig.savefig(os.path.join(OUT, "apbc-1-4-idea-%s.png" % _name),
                     format="png", dpi=150, bbox_inches="tight")
print("wrote", OUT)
