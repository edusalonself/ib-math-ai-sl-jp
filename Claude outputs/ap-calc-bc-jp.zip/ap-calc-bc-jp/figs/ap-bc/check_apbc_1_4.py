"""AP Calculus BC Unit 1.4 — Infinite limits, limits at infinity and asymptotes を検算する。

    python3 figs/ap-bc/check_apbc_1_4.py
"""
import glob
import os
import re
import sys

import sympy as sp

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
BASE = os.path.join(ROOT, "ap-bc", "01-limits")
QMD = os.path.join(BASE, "apbc-1-4.qmd")
TEXT = open(QMD, encoding="utf-8").read()
FIG = open(os.path.join(HERE, "make_apbc_1_4.py"), encoding="utf-8").read()
_NODOC = re.sub(r'"""(?:.|\n)*?"""', "", FIG)
FIGSTR = "\n".join(t for t in re.findall(r'r?"((?:[^"\\]|\\.)*)"', _NODOC)
                   if not t.startswith("#") and (" " in t or "$" in t))
FIGCODE = FIG.split('"""', 2)[-1]

OK = NG = 0


def chk(cond, msg):
    global OK, NG
    if cond:
        OK += 1
    else:
        NG += 1
        print("NG :", msg)


def eq(u, v, msg=""):
    chk(sp.simplify(sp.expand(u) - sp.expand(v)) == 0, msg + "  (%s vs %s)" % (u, v))


def in_text(sub, msg=""):
    chk(sub in TEXT, "本文に見つからない: " + msg + " :: " + sub[:70])


def not_in_text(sub, msg=""):
    chk(sub not in TEXT, "本文に残っている: " + msg + " :: " + sub[:70])


def in_fig(sub, msg=""):
    chk(sub in FIG, "図のスクリプトに見つからない: " + msg + " :: " + sub[:70])

_x, _a = sp.symbols("x a", real=True)
R = sp.Rational
OO = sp.oo


def nv(expr, val, n=20):
    return float(sp.N(expr.subs(_x, R(val)), n))


def fm(expr, val, fmt="%.4f"):
    return fmt % nv(expr, val)


# ══════════════════════════════════════════════════════════
# 0. The idea
# ══════════════════════════════════════════════════════════
# 第 1 節 無限大に発散する極限
chk(sp.limit(1 / (_x - 3) ** 2, _x, 3, "-") == OO, "第 1 節 1/(x-3)² は左も +∞")
chk(sp.limit(1 / (_x - 3) ** 2, _x, 3, "+") == OO, "第 1 節 1/(x-3)² は右も +∞")
chk(sp.limit(1 / (_x - 3), _x, 3, "-") == -OO, "第 1 節 1/(x-3) は左が -∞")
chk(sp.limit(1 / (_x - 3), _x, 3, "+") == OO, "第 1 節 1/(x-3) は右が +∞")
chk(fm(1 / (_x - 3), "2.99", "%.1f") == "-100.0", "第 1 節 x = 2.99 で -100")
chk(fm(1 / (_x - 3), "3.01", "%.1f") == "100.0", "第 1 節 x = 3.01 で 100")
# ★ 2 乗の有無で左右の符号が変わる（誤答側の区別）
chk(sp.limit(1 / (_x - 3) ** 2, _x, 3, "-")
    != sp.limit(1 / (_x - 3), _x, 3, "-"), "第 1 節 2 乗があると符号がちがう")

# 第 2 節 垂直漸近線（図と同じ関数）
_v = (2 * _x + 1) / (_x - 1)
chk((2 * _x + 1).subs(_x, 1) == 3, "第 2 節 分子は x = 1 で 3")
chk(sp.limit(_v, _x, 1, "-") == -OO and sp.limit(_v, _x, 1, "+") == OO,
    "第 2 節 左右で -∞ と +∞")
chk(fm(_v, "0.99", "%.0f") == "-298", "第 2 節 x = 0.99 で -298")
chk(fm(_v, "1.01", "%.0f") == "302", "第 2 節 x = 1.01 で 302")
chk(sp.limit(_v, _x, OO) == 2, "第 2 節 図の水平漸近線は y = 2")

# 第 3 節 無限遠での極限
chk(sp.limit(1 / _x, _x, OO) == 0 and sp.limit(1 / _x, _x, -OO) == 0,
    "第 3 節 1/x は両側とも 0")
_r3 = (3 * _x ** 2 + 1) / (_x ** 2 - 5)
chk(sp.limit(_r3, _x, OO) == 3, "第 3 節 極限は 3")
chk(fm(_r3, "100") == "3.0016", "第 3 節 x = 100 の値")
in_text("$\\dfrac{30001}{9995} = 3.0016\\ldots$", "第 3 節 検算の値")

# 第 4 節 次数の 3 つの場合
chk(sp.limit((2 * _x + 1) / (_x ** 2 + 3), _x, OO) == 0, "第 4 節 分子の次数が低い")
chk(sp.limit((3 * _x ** 2 - _x) / (_x ** 2 + 5), _x, OO) == 3, "第 4 節 次数が同じ")
chk(sp.limit(_x ** 3 / (_x ** 2 + 1), _x, OO) == OO, "第 4 節 分子の次数が高い")
chk(fm((2 * _x + 1) / (_x ** 2 + 3), "1000") == "0.0020", "第 4 節 x = 1000 の値")
# ★ 水平漸近線が 2 本になる例（有理式では起きない）
_two = _x / sp.sqrt(_x ** 2 + 1)
chk(sp.limit(_two, _x, OO) == 1 and sp.limit(_two, _x, -OO) == -1,
    "第 4 節 x/√(x²+1) は 1 と -1")
chk(sp.limit(_r3, _x, OO) == sp.limit(_r3, _x, -OO), "第 4 節 有理式では左右が同じ")

# 第 5 節 増え方
chk(sp.limit(_x ** 2 / sp.exp(_x), _x, OO) == 0, "第 5 節 x²/eˣ は 0")
chk(sp.limit(sp.log(_x) / _x, _x, OO) == 0, "第 5 節 ln x / x は 0")
for _p in (1, 2, 5, 10):
    chk(sp.limit(_x ** _p / sp.exp(_x), _x, OO) == 0, "第 5 節 x^%d/eˣ も 0" % _p)
chk("%.5f" % float(sp.N(100 / sp.exp(10), 20)) == "0.00454", "第 5 節 x = 10 の値")
chk("%.1f" % float(sp.N(sp.exp(10), 20)) == "22026.5", "第 5 節 e^10 の値")
# Why it works の数値
chk("%.3f" % float(sp.N(25 / sp.exp(5), 20)) == "0.168", "Why x = 5 の値")
chk(float(sp.N(25 / sp.exp(5), 20)) / float(sp.N(100 / sp.exp(10), 20)) > 37,
    "Why 37 分の 1 以下になっている")

# ══════════════════════════════════════════════════════════
# 1. 例題
# ══════════════════════════════════════════════════════════
_m1 = (_x + 4) / (_x - 2)
chk((_x + 4).subs(_x, 2) == 6, "例題1 分子は 6")
chk(sp.limit(_m1, _x, 2, "-") == -OO and sp.limit(_m1, _x, 2, "+") == OO,
    "例題1 片側極限")
chk(fm(_m1, "1.99", "%.0f") == "-599", "例題1 x = 1.99 の値")
chk(fm(_m1, "2.01", "%.0f") == "601", "例題1 x = 2.01 の値")
chk(sp.limit(_m1, _x, OO) == 1, "例題1 水平漸近線は y = 1")

_m2 = (5 * _x ** 2 - 3 * _x) / (2 * _x ** 2 + 7)
chk(sp.limit(_m2, _x, OO) == R(5, 2), "例題2 極限は 5/2")
chk(sp.limit(_m2, _x, -OO) == R(5, 2), "例題2 x → -∞ でも 5/2")
chk(fm(_m2, "100") == "2.4841", "例題2 x = 100 の値")
in_text("\\dfrac{49700}{20007} = 2.4841\\ldots", "例題2 検算の値")

_m3 = (_x ** 2 - 4) / (_x ** 2 - _x - 2)
eq(sp.factor(_x ** 2 - _x - 2), (_x - 2) * (_x + 1), "例題3 分母の因数分解")
eq(sp.factor(_x ** 2 - 4), (_x - 2) * (_x + 2), "例題3 分子の因数分解")
chk(sp.simplify(_m3 - (_x + 2) / (_x + 1)) == 0, "例題3 約分すると (x+2)/(x+1)")
chk(sp.limit(_m3, _x, 2) == R(4, 3), "例題3 x = 2 は穴（4/3）")
chk(sp.limit(_m3, _x, -1, "+") == OO, "例題3 x = -1 は垂直漸近線")
chk(sp.limit(_m3, _x, OO) == 1, "例題3 水平漸近線は y = 1")
chk(fm((_x + 2) / (_x + 1), "-1.01", "%.0f") == "-99", "例題3 x = -1.01 の値")
chk(fm((_x + 2) / (_x + 1), "-0.99", "%.0f") == "101", "例題3 x = -0.99 の値")
chk(fm((_x + 2) / (_x + 1), "1.999", "%.5f") == "1.33344", "例題3 x = 1.999 の値")
_v3 = nv((_x + 2) / (_x + 1), "2.001")
chk(1.33322 <= _v3 < 1.33323, "例題3 x = 2.001 は 1.33322… (%s)" % _v3)

chk(sp.limit(_x ** 3 / sp.exp(_x), _x, OO) == 0, "例題4 極限は 0")
chk("%.3f" % float(sp.N(125 / sp.exp(5), 20)) == "0.842", "例題4 x = 5 の値")
chk("%.1e" % float(sp.N(8000 / sp.exp(20), 20)) == "1.6e-05", "例題4 x = 20 の値")
chk("%.2e" % float(sp.N(sp.exp(20), 20)) == "4.85e+08", "例題4 e^20 の値")
# ★ x³ 自体は大きくなり続ける（比だけが 0 に行く）
chk(sp.limit(_x ** 3, _x, OO) == OO, "例題4 x³ 自体は発散する")

# ══════════════════════════════════════════════════════════
# 2. 演習
# ══════════════════════════════════════════════════════════
_e1 = 1 / (_x + 5) ** 2
chk(sp.limit(_e1, _x, -5, "-") == OO and sp.limit(_e1, _x, -5, "+") == OO,
    "演習1 両側とも +∞")
chk(fm(_e1, "-4.99", "%.0f") == "10000" and fm(_e1, "-5.01", "%.0f") == "10000",
    "演習1 x = -4.99, -5.01 の値")
chk(sp.limit(1 / (_x + 5), _x, -5, "-") == -OO, "演習1 2 乗がなければ -∞")
_a1 = ("VA", -5)

_e2 = (7 * _x + 2) / (3 * _x - 4)
chk(sp.limit(_e2, _x, OO) == R(7, 3), "演習2 極限は 7/3")
chk(sp.limit(_e2, _x, -OO) == R(7, 3), "演習2 x → -∞ でも 7/3")
chk(fm(_e2, "1000") == "2.3371", "演習2 x = 1000 の値")
_a2 = R(7, 3)

_e3 = (_x + 6) / (_x ** 2 + 1)
chk(sp.limit(_e3, _x, OO) == 0, "演習3 極限は 0")
chk(fm(_e3, "100") == "0.0106" or fm(_e3, "100", "%.5f") == "0.01060",
    "演習3 x = 100 の値")
chk(fm(_e3, "1000", "%.5f") == "0.00101" or fm(_e3, "1000", "%.4f") == "0.0010",
    "演習3 x = 1000 の値")
_a3 = 0

_e4 = (_x ** 3 + 2) / (_x + 1)
chk(sp.limit(_e4, _x, OO) == OO, "演習4 発散する")
chk(fm(_e4, "10", "%.2f") == "91.09", "演習4 x = 10 の値")
chk(fm(_e4, "100", "%.1f") == "9901.0", "演習4 x = 100 の値")
_a4 = "infinity"

_e5 = 3 / (_x - 4)
chk(sp.limit(_e5, _x, 4, "-") == -OO and sp.limit(_e5, _x, 4, "+") == OO,
    "演習5 片側極限")
chk(fm(_e5, "3.99", "%.0f") == "-300" and fm(_e5, "4.01", "%.0f") == "300",
    "演習5 x = 3.99, 4.01 の値")
chk(fm(_e5, "3.999", "%.0f") == "-3000" and fm(_e5, "4.001", "%.0f") == "3000",
    "演習5 x = 3.999, 4.001 の値")
_a5 = ("VA", 4)

_e6 = (_x ** 2 - 25) / (_x ** 2 - 3 * _x - 10)
eq(sp.factor(_x ** 2 - 3 * _x - 10), (_x - 5) * (_x + 2), "演習6 分母の因数分解")
eq(sp.factor(_x ** 2 - 25), (_x - 5) * (_x + 5), "演習6 分子の因数分解")
chk(sp.limit(_e6, _x, 5) == R(10, 7), "演習6 x = 5 は穴（10/7）")
chk(sp.limit(_e6, _x, -2, "+") == OO, "演習6 x = -2 は垂直漸近線")
chk(sp.limit(_e6, _x, OO) == 1, "演習6 水平漸近線は y = 1")
chk(fm((_x + 5) / (_x + 2), "4.999", "%.5f") == "1.42863", "演習6 x = 4.999 の値")
_v6 = nv((_x + 5) / (_x + 2), "5.001")
chk(1.42851 <= _v6 < 1.42852, "演習6 x = 5.001 は 1.42851… (%s)" % _v6)
chk(fm((_x + 5) / (_x + 2), "-2.01", "%.0f") == "-299", "演習6 x = -2.01 の値")
chk(fm((_x + 5) / (_x + 2), "-1.99", "%.0f") == "301", "演習6 x = -1.99 の値")
_a6 = ("hole", R(10, 7))

chk(sp.limit(sp.log(_x) / _x ** 2, _x, OO) == 0, "演習7 ln x / x² は 0")
chk(sp.limit(_x ** 2 / 2 ** _x, _x, OO) == 0, "演習7 x²/2ˣ は 0")
chk("%.2f" % float(sp.N(sp.log(10), 20)) == "2.30", "演習7 ln 10 の値")
chk(2 ** 10 == 1024 and 10 ** 2 == 100, "演習7 x = 10 の値")
chk(2 ** 4 == 4 ** 2, "演習7 x = 4 ではまだ同じ")
_a7 = "ln x < x² < 2^x"

_e8 = (_a * _x + 3) / (_x - 2)
chk(sp.solve(sp.Eq(sp.limit(_e8, _x, OO), 4), _a) == [4], "演習8 a = 4")
chk(sp.limit(_e8.subs(_a, 4), _x, OO) == 4, "演習8 a = 4 で y = 4")
chk(sp.limit(_e8.subs(_a, 4), _x, -OO) == 4, "演習8 x → -∞ でも 4")
chk(sp.solve(sp.Eq(2 * _a + 3, 0), _a) == [R(-3, 2)], "演習8 分子が 0 になる a")
chk(sp.simplify((R(-3, 2) * _x + 3) / (_x - 2) + R(3, 2)) == 0,
    "演習8 a = -3/2 なら定数（穴）")
chk(fm(_e8.subs(_a, 4), "100") == "4.1122", "演習8 a = 4, x = 100 の値")
_a8 = 4

_e9 = (2 * _x ** 2 + 5) / (_x ** 2 - 9)
eq(sp.factor(_x ** 2 - 9), (_x - 3) * (_x + 3), "演習9 分母の因数分解")
chk(sp.solve(2 * _x ** 2 + 5, _x) == [] or all(not _s.is_real
    for _s in sp.solve(2 * _x ** 2 + 5, _x)), "演習9 分子は実数解を持たない")
chk(sp.limit(_e9, _x, 3, "-") == -OO and sp.limit(_e9, _x, 3, "+") == OO,
    "演習9 x = 3 の片側極限")
chk(sp.limit(_e9, _x, -3, "-") == OO and sp.limit(_e9, _x, -3, "+") == -OO,
    "演習9 x = -3 の片側極限")
chk(sp.limit(_e9, _x, OO) == 2, "演習9 水平漸近線は y = 2")
chk(fm(_e9, "2.99", "%.1f") == "-382.0", "演習9 x = 2.99 の値")
chk(fm(_e9, "-3.01", "%.1f") == "384.7", "演習9 x = -3.01 の値")
chk(nv(2 * _x ** 2 + 5, "0") >= 5, "演習9 分子は 5 以上")
_a9 = ("VA ±3", 2)

_e10 = (3 * _x ** 2 + 1) / (_x ** 3 - 2)
chk(sp.limit(_e10, _x, OO) == 0, "演習10 極限は 0")
chk(sp.degree(3 * _x ** 2 + 1, _x) == 2 and sp.degree(_x ** 3 - 2, _x) == 3,
    "演習10 次数は 2 と 3")
chk(fm(_e10, "100") == "0.0300", "演習10 x = 100 の値")
chk(fm(_e10, "1000", "%.4f") == "0.0030", "演習10 x = 1000 の値")
# ★ 係数の比 3 は、次数が同じときの答え（誤答側）
chk(sp.limit((3 * _x ** 3 + 1) / (_x ** 3 - 2), _x, OO) == 3,
    "演習10 次数が同じなら 3 になる")
_a10 = "0 (degrees differ)"

_ans = [_a1, _a2, _a3, _a4, _a5, _a6, _a7, _a8, _a9, _a10]
chk(len(set(map(str, _ans))) == len(_ans), "演習の答えが重複していない: %s" % (_ans,))

# ══════════════════════════════════════════════════════════
# 本文が例題・演習の答えを先に見せていないこと
# ══════════════════════════════════════════════════════════
_body = TEXT[:TEXT.index("\n## Worked examples")]
for _leak in ("\\frac{7}{3}", "\\frac{5}{2}", "\\frac{10}{7}", "\\frac{4}{3}",
              "2x^{2}+5", "x^{2}-25", "x^{2}-3x-10", "ax+3", "x^{3}+2",
              "(x+5)^{2}", "x^{3}-2"):
    chk(_leak not in _body, "本文が答えを先に見せている: " + _leak)
# ══════════════════════════════════════════════════════════
# 構成
# ══════════════════════════════════════════════════════════
_tips = re.findall(r"::: \{\.callout-tip collapse=\"true\"\}\n## (.+)", TEXT)
_gdc = [h for h in _tips
        if not h.startswith("解説") and h != "クリックすると開きます"]
chk(len(_gdc) == 1, "電卓の折りたたみは 1 つ: %s" % _gdc)
for _h in _gdc:
    chk(_h.startswith("Section I Part B と Section II Part A では"),
        "電卓の見出しが Section I Part B で始まる: " + _h)
chk("## Using your GDC" not in TEXT, "独立した GDC の節は置いていない")
in_text("**Section I Part A と Section II Part B では使えません。**",
        "電卓が使えない区分を明記")
for _m in ["Casio", "fx-CG50", "TI-84", "OPTN", "PRB", "cSolve", "nDeriv"]:
    not_in_text(_m, "他機種・確かめていない機能: " + _m)
for _m in ["Paper 1", "Paper 2", "IB ", "GDC"]:
    not_in_text(_m, "IB の言いまわしが残っている: " + _m)
not_in_text("## 参考：この項目のシラバス（原文）", "末尾のシラバスは置かない")
# ★ 決めごと（_AP-BC-PLAN.md）: dx は斜体、逆三角は \arctan
not_in_text("\\mathrm{d}", "dx は斜体に統一（\\mathrm{d} を使わない）")
not_in_text("\\tan^{-1}", "逆三角関数は \\arctan に統一")
chk(len([l for l in TEXT.splitlines() if l.rstrip() == "---"]) == 6, "--- は 6 本")
chk(TEXT.count('<details class="jp-trans">') == 14, "日本語訳が 14")
chk(TEXT.count("</details>") == 14, "</details> も 14")
chk(TEXT.count("{.ex-sep}") == 9, "ex-sep が 9")
chk(TEXT.count("{.ex-no}") == 10, "演習が 10")
chk(TEXT.count("{.model-answer}") == 4, "model-answer が 4")
chk(len(re.findall(r"^::: \{#exm-apbc14-", TEXT, re.M)) == 4, "例題が 4")
chk(TEXT.count("## 解答例（答案用紙に書くこと）") == 14, "解答例が 14")
_h2 = re.findall(r"^## (.+)$", TEXT, re.M)
_want = ["The idea", "Why it works", "Worked examples", "Common errors",
         "Exercises"]
chk([h for h in _h2 if h in _want] == _want, "5 つの見出しが所定の順")
_nums = [int(_v) for _v in re.findall(r"^### (\d+)\. ", TEXT, re.M)]
chk(_nums == list(range(1, len(_nums) + 1)) and 5 <= len(_nums) <= 7,
    "The idea が 1.. の連番（5〜7 節）: %s" % _nums)
chk(TEXT.count("**検算") >= 12, "検算が十分ある: %d" % TEXT.count("**検算"))
not_in_text("**確かめ", "検算は「検算」で統一")
for word in ["誰でもできる", "簡単です", "当然", "明らか", "もちろん",
             "当たり前", "そのとおり"]:
    not_in_text(word, "禁止語")
_ce = TEXT[TEXT.index("\n## Common errors"):TEXT.index("\n## Exercises")]
chk(_ce.count("::: {.callout-warning}") == 6, "Common errors が 6 つ")
# ★ AP の答案作法（引き継ぎ §6.3）を Common errors に必ず 1 つ入れる
chk(("Justify" in _ce or "Explain" in _ce)
    and ("単位" in _ce or "途中の式" in _ce or "根拠" in _ce),
    "Common errors に AP の答案作法がある")
_MASKED = TEXT.replace("\\$", "")
for _blk in re.findall(r"\$\$(.*?)\$\$", _MASKED, re.S):
    chk("✓" not in _blk and "✗" not in _blk, "表示数式に ✓/✗: " + _blk[:40])
for _blk in re.findall(r"(?<!\$)\$([^$\n]+)\$(?!\$)", _MASKED):
    chk("✓" not in _blk and "✗" not in _blk, "インライン数式に ✓/✗: " + _blk[:40])
chk(all("@eq-" not in TEXT.split("$$")[i] for i in range(1, len(TEXT.split("$$")), 2)),
    "表示数式の中に @-ref がない")
for _blk in re.findall(r"::: \{\.model-answer\}(.*?):::", TEXT, re.S):
    chk(not re.search(r"[ぁ-んァ-ン一-龥]",
                      _blk.replace("**試験ではこう書く**", "")),
        "model-answer に日本語")
_anchors = set(re.findall(r"\{#([a-z0-9-]+)\}", TEXT))
for _a0 in set(re.findall(r"\]\(#([a-z0-9-]+)\)", TEXT)):
    chk(_a0 in _anchors or _a0 in {"why-it-works", "common-errors", "exercises"},
        "ページ内リンク先がない: #" + _a0)
for _r0 in set(re.findall(r"@(?:exm|eq|fig|tbl)-([a-z0-9]+)-", TEXT)):
    chk(_r0 == "apbc14", "他ページの @-ref: " + _r0)
for _href in re.findall(r"\]\(([^)]+\.qmd[^)]*)\)", TEXT):
    chk(os.path.exists(os.path.normpath(os.path.join(
        os.path.dirname(QMD), _href.split("#")[0]))),
        "リンク先のページがない: " + _href)
_head = TEXT[:TEXT.index("## The idea")]
chk(_head.count("::: {.callout-note}") == 1 and _head.count(":::") == 2,
    "冒頭の callout は 1 つだけ")
not_in_text("**この節ですること：", "節の頭の 1 文は置かない")
not_in_text("\\vec{", "ベクトルの記号は太字")
chk(len(re.findall(r"^::: ", TEXT, re.M)) == len(re.findall(r"^:::$", TEXT, re.M)),
    "::: の開閉が一致")
for _h in re.findall(r"^#{1,4} .+$", TEXT, re.M):
    chk(not re.search(r"\$\s*—", _h), "見出しで数式の直後に —: " + _h)
_i = TEXT.index(chr(10) + "## Why it works" + chr(10))
_j = TEXT.index(chr(10) + "## Worked examples", _i)
_wiw = TEXT[_i:_j]
chk('collapse="true"}' + chr(10) + "## クリックすると開きます" in _wiw,
    "Why it works は折りたたんである")
chk(_wiw.rstrip().endswith(":::"), "折りたたみが閉じてある")
# ★ The idea の見出しは「英語（日本語）」の形
for _hh in re.findall(r"^### \d+\. (.+?) \{#", TEXT, re.M):
    chk(_hh.endswith("）") and "（" in _hh,
        "見出しが 英語（日本語） の形でない: " + _hh)
    chk(re.match(r"[A-Za-z$]", _hh) is not None,
        "見出しが英語で始まっていない: " + _hh)
    _en = _hh[:_hh.rindex("（")]
    chk(not re.search(r"[ぁ-んァ-ヶ一-龥]", _en),
        "見出しの英語の側に日本語がある: " + _hh)

# ══════════════════════════════════════════════════════════
# 図
# ══════════════════════════════════════════════════════════
for _n in ("a", "b"):
    _p = os.path.join(BASE, "img", "apbc-1-4-idea-%s.svg" % _n)
    chk(os.path.exists(_p), "図 (%s) がある" % _n)
    chk("](img/apbc-1-4-idea-%s.svg)" % _n in TEXT,
        "本文が図 (%s) を貼っている" % _n)
for _s0 in glob.glob(os.path.join(BASE, "img", "*.png")):
    chk(False, "PNG が残っている: " + os.path.basename(_s0))
for bad in ["pmatrix", "\\lvert", "\\rvert"]:
    chk(bad not in FIGCODE, "図で使えない記法: " + bad)
chk(not re.search(r"[ぁ-んァ-ン]", FIGSTR), "図のラベルに日本語がない")
# ★ ここに、このページ固有の図の検査を書いてください。
#    図の見出しとラベルを in_fig で逐語に押さえ、図の数値が本文と
#    合っていること、図が例題・演習の答えを載せていないことを見ます。
#    見本: figs/ap-bc/check_apbc_1_4.py

# ══════════════════════════════════════════════════════════
# 登録
# ══════════════════════════════════════════════════════════
DRAFT = open(os.path.join(ROOT, "_quarto-draft.yml"), encoding="utf-8").read()
chk("ap-bc/01-limits/apbc-1-4.qmd" in DRAFT, "draft に登録")
PUB = open(os.path.join(ROOT, "_quarto.yml"), encoding="utf-8").read()
chk("ap-bc" not in PUB, "公開用には入れない")
chk("G-LQBB7M9VZ0" not in PUB, "IB の本の測定 ID を流用していない")
IDX = open(os.path.join(ROOT, "ap-bc", "index.qmd"), encoding="utf-8").read()
chk("(01-limits/apbc-1-4.qmd)" in IDX, "index にある")
_written = sorted(glob.glob(os.path.join(ROOT, "ap-bc", "*", "apbc-*.qmd")))
chk(len(re.findall(r"^\| \*\*Unit [0-9.]+\*\* \|.*✅", IDX, re.M)) == len(_written),
    "✅ の数とページ数が合う")
_mm = re.search(r"いまのところ (\d+) ページです（全 (\d+) ページ）", IDX)
chk(_mm is not None and int(_mm.group(1)) == len(_written), "「いまのところ N」")
chk(_mm is not None and int(_mm.group(2)) == 45, "全 45 ページ")
_rows = re.findall(r"^\| \*\*Unit [0-9.]+\*\* \|", IDX, re.M)
chk(len(_rows) == 45, "一覧表の行が 45: %d" % len(_rows))
PLAN = open(os.path.join(ROOT, "_AP-BC-PLAN.md"), encoding="utf-8").read()
_pm = re.search(r"\*\*進捗：(\d+) / 45 ページ。\*\*", PLAN)
chk(_pm is not None and int(_pm.group(1)) == len(_written), "PLAN の進捗")
GLO = open(os.path.join(ROOT, "glossary-ap.qmd"), encoding="utf-8").read()
for t in ["| limit |", "| one-sided limit |", "| left-hand limit |",
          "| right-hand limit |", "| does not exist |", "| indeterminate form |",
          "| average rate of change |", "| instantaneous rate of change |"]:
    chk(t in GLO, "対訳表にある: " + t)
# ★ .gitignore が College Board の PDF を止めているか
GI = open(os.path.join(ROOT, ".gitignore"), encoding="utf-8").read()
chk(re.search(r"^\*\.pdf$", GI, re.M) is not None, ".gitignore に *.pdf がある")


# ══════════════════════════════════════════════════════════
# ページ固有: CED の逐語引用と、見張り
# ══════════════════════════════════════════════════════════
in_text("**このページが扱う CED Topic：1.14・1.15**", "CED Topic の明記")
not_in_text("**BC only**", "このページは BC 限定ではない")

in_text("> The concept of a limit can be extended to include infinite limits.",
        "CED LIM-2.D.1")
in_text("> Asymptotic and unbounded behavior of functions can be described and "
        "explained using limits.", "CED LIM-2.D.2")
in_text("> The concept of a limit can be extended to include limits at infinity.",
        "CED LIM-2.D.3")
in_text("> Limits at infinity describe end behavior.", "CED LIM-2.D.4")
in_text("> Relative magnitudes of functions and their rates of change can be "
        "compared using limits.", "CED LIM-2.D.5")

# 言い切りの見張り
in_text("**これは「極限が存在する」という意味ではありません**", "∞ は値ではない")
in_text("**分母が $0$ になるだけでは足りません。**", "穴との区別")
in_text("**水平漸近線は、$2$ 本まで**", "2 本までの注意")
in_text("**なぜそうなるかは、Unit 4.3 のロピタルの定理で確かめます。**", "前方参照は文章で")
in_text("**$x^{3}$ が小さくなるわけではありません。**", "比の意味")
not_in_text("](apbc-4-3.qmd", "まだ無いページにリンクしていない")
# 書いたページへのリンクは、ファイルもアンカーも実在すること
for _href, _anchor, _sec in (("apbc-1-1.qmd", "{#dne}", "### 6. "),
                             ("apbc-1-2.qmd", "{#factor}", "### 3. "),
                             ("apbc-1-3.qmd", "{#types}", "### 2. ")):
    _p = open(os.path.join(BASE, _href), encoding="utf-8").read()
    chk(_anchor in _p, "リンク先にアンカーがある: " + _href + _anchor)
    chk(_sec in _p, "リンク先に節番号がある: " + _href + " " + _sec)
in_text("[Unit 1.1 第 6 節](apbc-1-1.qmd#dne)", "Unit 1.1 へのリンク")
in_text("[Unit 1.2 第 3 節](apbc-1-2.qmd#factor)", "Unit 1.2 へのリンク")
in_text("[Unit 1.3 第 2 節](apbc-1-3.qmd#types)", "Unit 1.3 へのリンク")

# ══════════════════════════════════════════════════════════
# 図
# ══════════════════════════════════════════════════════════
in_fig("the graph hugs $x = 1$ and flattens towards $y = 2$", "図 (a) の見出し")
in_fig("vertical asymptote:\\nthe values blow up", "図 (a) の説明")
in_fig("horizontal asymptote:\\nthe end behaviour", "図 (a) の説明")
in_fig("$y = \\\\dfrac{2x+1}{x-1}$", "図 (a) の関数")
in_fig("for large $x$, the exponential runs away from the others", "図 (b) の見出し")
for _w in ("$y = e^{x}$", "$y = x^{2}$"):
    in_fig(_w, "図 (b) のラベル: " + _w)
# ★ 図 (a) の関数は、本文の第 2 節と同じ
chk("(2 * _t + 1) / (_t - 1)" in FIGCODE, "図 (a) は (2x+1)/(x-1)")
in_text("@fig-apbc14-idea-a は $y = \\dfrac{2x+1}{x-1}$ です。", "本文も同じ関数")
chk("ax1.axvline(1," in FIGCODE and "ax1.axhline(2," in FIGCODE,
    "図 (a) は x = 1 と y = 2 を引いている")
# ★ 図が例題・演習の答えを載せていないこと
for _leak in ("7/3", "5/2", "10/7", "4/3", "= 4"):
    chk(_leak not in FIGSTR, "図のラベルが答えを載せている: " + _leak)

# ══════════════════════════════════════════════════════════
# 用語集（このページで初出の語）
# ══════════════════════════════════════════════════════════
for t in ["| infinite limit |", "| limit at infinity |", "| horizontal asymptote |",
          "| end behaviour |", "| leading coefficient |", "| degree |"]:
    chk(t in GLO, "対訳表にある: " + t)

print()
print("OK", OK, "/ NG", NG)
sys.exit(1 if NG else 0)
