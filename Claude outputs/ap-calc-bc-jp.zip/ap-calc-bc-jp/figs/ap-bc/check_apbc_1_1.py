"""AP Calculus BC Unit 1.1 — Limits: reading them from graphs and tables を検算する。

    python3 figs/ap-bc/check_apbc_1_1.py
"""
import glob
import os
import re
import sys

import sympy as sp

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
BASE = os.path.join(ROOT, "ap-bc", "01-limits")
QMD = os.path.join(BASE, "apbc-1-1.qmd")
TEXT = open(QMD, encoding="utf-8").read()
FIG = open(os.path.join(HERE, "make_apbc_1_1.py"), encoding="utf-8").read()
_NODOC = re.sub(r'"""(?:.|\n)*?"""', "", FIG)
FIGSTR = "\n".join(t for t in re.findall(r'r?"((?:[^"\\]|\\.)*)"', _NODOC)
                   if not t.startswith("#") and (" " in t or "$" in t))
FIGCODE = FIG.split('"""', 2)[-1]

OK = NG = 0


def chk(cond, msg):
    global OK, NG
    if cond:
        OK += 1
    else:
        NG += 1
        print("NG :", msg)


def eq(u, v, msg=""):
    chk(sp.simplify(sp.expand(u) - sp.expand(v)) == 0, msg + "  (%s vs %s)" % (u, v))


def in_text(sub, msg=""):
    chk(sub in TEXT, "本文に見つからない: " + msg + " :: " + sub[:70])


def not_in_text(sub, msg=""):
    chk(sub not in TEXT, "本文に残っている: " + msg + " :: " + sub[:70])


def in_fig(sub, msg=""):
    chk(sub in FIG, "図のスクリプトに見つからない: " + msg + " :: " + sub[:70])


_x, _h, _k, _d, _t = sp.symbols("x h k d t", real=True)
R = sp.Rational


def six(expr, val):
    """expr に val を入れて、小数第 6 位で丸めた文字列。本文の表と照合する。"""
    return "%.6f" % float(sp.N(expr.subs(_x, R(val)), 25))


def three(expr, val):
    return "%.3f" % float(sp.N(expr.subs(_x, R(val)), 25))


# ══════════════════════════════════════════════════════════
# 0. The idea — 平均変化率から極限へ（第 1・2 節）
# ══════════════════════════════════════════════════════════
_avg = ((1 + _h) ** 2 - 1 ** 2) / _h
eq(sp.simplify(_avg), 2 + _h, "第 1 節 平均変化率は 2+h")
chk(sp.limit(_avg, _h, 0) == 2, "第 1 節 h→0 の極限は 2")
# ★ h = 0 は代入できない（分母が 0）。約分できるのは h ≠ 0 のときだけ。
chk(sp.denom(sp.together(_avg)).subs(_h, 0) == 0, "第 1 節 h = 0 では分母が 0")
for _v, _want in (("0.1", "2.1"), ("0.01", "2.01"), ("-0.01", "1.99")):
    chk(str(sp.nsimplify(sp.N((2 + _h).subs(_h, R(_v)), 10))) == str(sp.Rational(_want)),
        "第 1 節 h = %s の値" % _v)
in_text("$h = 0.1$ なら $2.1$、$h = 0.01$ なら $2.01$、$h = -0.01$ なら $1.99$",
        "第 1 節 検算の値")
# 誤答側: 約分を間違えて 2h + h^2 を h で割り忘れると 2h + h^2 → h→0 で 0 になり、
# 速さが 0 という誤った結論になる。検算がこれを区別することを確かめる。
chk(sp.limit(2 * _h + _h ** 2, _h, 0) == 0, "第 1 節 割り忘れると 0 になる（誤答側）")
chk(sp.limit(2 * _h + _h ** 2, _h, 0) != sp.limit(_avg, _h, 0),
    "第 1 節 検算は割り忘れを区別する")

# ══════════════════════════════════════════════════════════
# 1. 第 5 節の表（√x − 2）/(x − 4)
# ══════════════════════════════════════════════════════════
_f5 = (sp.sqrt(_x) - 2) / (_x - 4)
chk(sp.limit(_f5, _x, 4) == R(1, 4), "第 5 節 極限は 1/4")
_tab5 = [("3.9", "0.251582"), ("3.99", "0.250156"), ("3.999", "0.250016"),
         ("4.001", "0.249984"), ("4.01", "0.249844"), ("4.1", "0.248457")]
for _v, _s in _tab5:
    chk(six(_f5, _v) == _s, "第 5 節 表 x = %s は %s（実際 %s）" % (_v, _s, six(_f5, _v)))
    in_text("$%s$" % _s, "第 5 節 表の値")
# 左からは下から、右からは上から寄る
chk(float(sp.N(_f5.subs(_x, R("4.001")))) < 0.25 < float(sp.N(_f5.subs(_x, R("3.999")))),
    "第 5 節 左は 0.25 より大きく、右は小さい")
in_text("左からは上から下がり、右からは下から上がって", "第 5 節 寄り方")
# $3.9$ と $4.1$ だけでは足りない（第 3 位が決まらない）
chk(three(_f5, "3.9") != three(_f5, "3.999"), "第 5 節 0.1 刻みでは第 3 位が決まらない")
chk(three(_f5, "3.999") == "0.250" and three(_f5, "4.001") == "0.250",
    "第 5 節 0.001 刻みなら第 3 位が決まる")

# ══════════════════════════════════════════════════════════
# 2. 第 6 節 — 極限が存在しない 3 つの形
# ══════════════════════════════════════════════════════════
_sgn = sp.Abs(_x) / _x
chk(sp.limit(_sgn, _x, 0, "-") == -1, "第 6 節 |x|/x の左側は -1")
chk(sp.limit(_sgn, _x, 0, "+") == 1, "第 6 節 |x|/x の右側は 1")
chk(sp.limit(_sgn, _x, 0, "-") != sp.limit(_sgn, _x, 0, "+"), "第 6 節 左右がちがう")
chk(sp.limit(1 / _x ** 2, _x, 0) == sp.oo, "第 6 節 1/x² は限りなく大きくなる")
chk(sp.limit(1 / _x ** 2, _x, 0, "-") == sp.oo, "第 6 節 左側も +∞（2 乗だから）")

# ══════════════════════════════════════════════════════════
# 3. Why it works — 表が見落とす例（sin(1/x)）
# ══════════════════════════════════════════════════════════
for _n in (1, 2, 3):
    chk(sp.sin(1 / (1 / (_n * sp.pi))) == 0, "Why 表の点 x = 1/(%dπ) では 0" % _n)
chk(sp.simplify(sp.sin(1 / (2 / sp.pi)) - 1) == 0, "Why x = 2/π では 1")
chk(sp.simplify(sp.sin(1 / (2 / (5 * sp.pi))) - 1) == 0, "Why x = 2/(5π) では 1")
chk(sp.limit(sp.sin(1 / _x), _x, 0) != 0, "Why sin(1/x) の極限は 0 ではない")
in_text("**表が見落としていた**", "Why 表の弱さ")

# ══════════════════════════════════════════════════════════
# 4. 例題
# ══════════════════════════════════════════════════════════
# 例題1 場合分け 3x+1 / 10-x
_L1, _R1 = 3 * _x + 1, 10 - _x
chk(_L1.subs(_x, 2) == 7, "例題1 左側極限 7")
chk(_R1.subs(_x, 2) == 8, "例題1 右側極限 8")
chk(_L1.subs(_x, 2) != _R1.subs(_x, 2), "例題1 極限は存在しない")
chk(sp.N(_L1.subs(_x, R("1.99"))) == 6.97, "例題1 x = 1.99 で 6.97")
chk(sp.N(_R1.subs(_x, R("2.01"))) == 7.99, "例題1 x = 2.01 で 7.99")
in_text("$3(1.99) + 1 = 6.97$", "例題1 検算の値")
in_text("$10 - 2.01 = 7.99$", "例題1 検算の値")
# 誤答側: 式を取りちがえると (a) が 8、(b) が 7 になる
chk(_R1.subs(_x, 2) == 8 and _L1.subs(_x, 2) == 7, "例題1 取りちがえると答えが入れかわる")

# 例題2 (2^x − 1)/x の表
_f2 = (2 ** _x - 1) / _x
chk(sp.limit(_f2, _x, 0) == sp.log(2), "例題2 極限は ln 2")
_tab2 = [("-0.1", "0.669670"), ("-0.01", "0.690750"), ("-0.001", "0.692907"),
         ("0.001", "0.693387"), ("0.01", "0.695555"), ("0.1", "0.717735")]
for _v, _s in _tab2:
    chk(six(_f2, _v) == _s, "例題2 表 x = %s は %s（実際 %s）" % (_v, _s, six(_f2, _v)))
    in_text("$%s$" % _s, "例題2 表の値")
chk(three(_f2, "-0.001") == "0.693" and three(_f2, "0.001") == "0.693",
    "例題2 内側の 2 つはどちらも 0.693 に丸まる")
chk("%.3f" % float(sp.N(sp.log(2), 25)) == "0.693", "例題2 ln 2 も 0.693")
# 誤答側: 0.694 には寄らない（右側は x を小さくするほど下がる）
chk(float(sp.N(_f2.subs(_x, R("0.001")))) < 0.694, "例題2 0.694 は候補にならない")
chk(float(sp.N(_f2.subs(_x, R("0.001")))) > float(sp.N(_f2.subs(_x, R("0.0001")))),
    "例題2 右側は x を小さくすると下がる")
chk(float(sp.N(_f2.subs(_x, R("-0.001")))) < 0.693 < float(sp.N(_f2.subs(_x, R("0.001")))),
    "例題2 0.693 は内側 2 つのあいだ")
# x = 0 は 0/0
chk(sp.Integer(2) ** 0 - 1 == 0, "例題2 分子は 0")

# 例題3 (x²−5x+6)/(x−3)、g(3) = 4
_g = (_x ** 2 - 5 * _x + 6) / (_x - 3)
eq(sp.factor(_x ** 2 - 5 * _x + 6), (_x - 2) * (_x - 3), "例題3 因数分解")
eq(sp.expand((_x - 2) * (_x - 3)), _x ** 2 - 5 * _x + 6, "例題3 展開して戻る")
chk(sp.simplify(_g - (_x - 2)) == 0, "例題3 x ≠ 3 で x − 2")
chk(sp.limit(_g, _x, 3) == 1, "例題3 極限は 1")
chk(sp.N((_x - 2).subs(_x, R("2.999"))) == 0.999, "例題3 x = 2.999 で 0.999")
chk(sp.N((_x - 2).subs(_x, R("3.001"))) == 1.001, "例題3 x = 3.001 で 1.001")
chk(sp.limit(_g, _x, 3) != 4, "例題3 極限と g(3) はちがう")

# 例題4 反例 h(x) = 2 (x ≠ 4), h(4) = 9
chk(sp.limit(sp.Integer(2), _x, 4) == 2, "例題4 定数 2 の極限は 2")
chk(2 != 9, "例題4 極限 2 と h(4) = 9 はちがう")

# ══════════════════════════════════════════════════════════
# 5. 演習
# ══════════════════════════════════════════════════════════
# 1 x² / 2x+1
_e1L, _e1R = _x ** 2, 2 * _x + 1
chk(_e1L.subs(_x, 1) == 1, "演習1 左側 1")
chk(_e1R.subs(_x, 1) == 3, "演習1 右側 3")
chk(sp.N(_e1L.subs(_x, R("0.99"))) == 0.9801, "演習1 x = 0.99 で 0.9801")
chk(sp.N(_e1R.subs(_x, R("1.01"))) == 3.02, "演習1 x = 1.01 で 3.02")
chk(abs(float(_e1R.subs(_x, 1) - _e1L.subs(_x, 1))) == 2, "演習1 差は 2 のまま")
_a1 = ("DNE", 1, 3)

# 2 (3^x − 1)/x の表
_f3 = (3 ** _x - 1) / _x
chk(sp.limit(_f3, _x, 0) == sp.log(3), "演習2 極限は ln 3")
_tab3 = [("-0.01", "1.092600"), ("-0.001", "1.098009"), ("-0.0001", "1.098552"),
         ("0.0001", "1.098673"), ("0.001", "1.099216"), ("0.01", "1.104669")]
for _v, _s in _tab3:
    chk(six(_f3, _v) == _s, "演習2 表 x = %s は %s（実際 %s）" % (_v, _s, six(_f3, _v)))
    in_text("$%s$" % _s, "演習2 表の値")
chk(three(_f3, "-0.0001") == "1.099" and three(_f3, "0.0001") == "1.099",
    "演習2 内側の 2 つはどちらも 1.099")
chk("%.3f" % float(sp.N(sp.log(3), 25)) == "1.099", "演習2 ln 3 も 1.099")
# ★ 外側では第 3 位が決まらない（これが解説の主張）
chk(three(_f3, "-0.001") == "1.098", "演習2 x = -0.001 では 1.098 になってしまう")
chk(three(_f3, "-0.001") != three(_f3, "-0.0001"), "演習2 近づけ方が足りないと値が変わる")
in_text("$1.098$ で、$1$ つ手前の桁がちがいます", "演習2 解説の主張")
_a2 = sp.log(3)

# 3 記号（数値なし）
in_text("\\lim_{x \\to 5^{-}} f(x) = -2", "演習3 (a)")
in_text("\\lim_{x \\to -1} g(x) = 7", "演習3 (b)")
in_text("もとの文より弱くなります", "演習3 片側で書く誤りの見張り")

# 4 (x²−x−6)/(x−3)
_e4 = (_x ** 2 - _x - 6) / (_x - 3)
eq(sp.factor(_x ** 2 - _x - 6), (_x + 2) * (_x - 3), "演習4 因数分解")
eq(sp.expand((_x + 2) * (_x - 3)), _x ** 2 - _x - 6, "演習4 展開して戻る")
chk(sp.limit(_e4, _x, 3) == 5, "演習4 極限は 5")
chk(sp.N((_x + 2).subs(_x, R("2.999"))) == 4.999, "演習4 x = 2.999 で 4.999")
chk(sp.N((_x + 2).subs(_x, R("3.001"))) == 5.001, "演習4 x = 3.001 で 5.001")
chk(sp.denom(sp.together(_e4)).subs(_x, 3) == 0, "演習4 x = 3 で分母が 0")
_a4 = 5

# 5 1/(x−4)²
_e5 = 1 / (_x - 4) ** 2
chk(sp.limit(_e5, _x, 4, "+") == sp.oo, "演習5 右から限りなく大きい")
chk(sp.limit(_e5, _x, 4, "-") == sp.oo, "演習5 左からも限りなく大きい")
chk(_e5.subs(_x, R("4.01")) == 10000, "演習5 x = 4.01 で 10000")
chk(_e5.subs(_x, R("4.001")) == 1000000, "演習5 x = 4.001 で 1000000")
chk(_e5.subs(_x, R("3.99")) == 10000, "演習5 x = 3.99 でも 10000（左右対称）")
chk(_e5.subs(_x, R("3.99")) == _e5.subs(_x, R("4.01")),
    "演習5 符号のちがいでは説明できない")
_a5 = "unbounded"

# 6 |x−2|/(x−2)
_e6 = sp.Abs(_x - 2) / (_x - 2)
chk(sp.limit(_e6, _x, 2, "+") == 1, "演習6 右側 1")
chk(sp.limit(_e6, _x, 2, "-") == -1, "演習6 左側 -1")
chk(_e6.subs(_x, R("2.5")) == 1, "演習6 x = 2.5 で 1")
chk(_e6.subs(_x, R("1.5")) == -1, "演習6 x = 1.5 で -1")
chk(_e6.subs(_x, R("2.001")) == 1 and _e6.subs(_x, R("1.999")) == -1,
    "演習6 近づけても値は変わらない")
_a6 = ("DNE", -1, 1)

# 7 表だけの問題（左は 6−x、右は 8−x で作った値）
_L7, _R7 = 6 - _x, 8 - _x
_tab7L = [("0.9", "5.100"), ("0.99", "5.010"), ("0.999", "5.001")]
_tab7R = [("1.001", "6.999"), ("1.01", "6.990"), ("1.1", "6.900")]
for _v, _s in _tab7L:
    chk("%.3f" % float(sp.N(_L7.subs(_x, R(_v)), 25)) == _s, "演習7 左の表 %s" % _v)
    in_text("$%s$" % _s, "演習7 表の値")
for _v, _s in _tab7R:
    chk("%.3f" % float(sp.N(_R7.subs(_x, R(_v)), 25)) == _s, "演習7 右の表 %s" % _v)
    in_text("$%s$" % _s, "演習7 表の値")
chk(_L7.subs(_x, 1) == 5 and _R7.subs(_x, 1) == 7, "演習7 片側極限は 5 と 7")
# 差が 10 分の 1 ずつ縮む
_dl = [abs(float(sp.N(_L7.subs(_x, R(_v)) - 5))) for _v, _ in _tab7L]
chk(all(abs(_dl[_i] / _dl[_i + 1] - 10) < 1e-9 for _i in range(2)),
    "演習7 左の差は 10 分の 1 ずつ")
_dr = [abs(float(sp.N(_R7.subs(_x, R(_v)) - 7))) for _v, _ in _tab7R]
chk(all(abs(_dr[_i + 1] / _dr[_i] - 10) < 1e-9 for _i in range(2)),
    "演習7 右の差は 10 倍ずつ離れる")
# 誤読の見張り: 右端 6.900 に寄ると読むと 7 ではなく 6.9 になる
chk(float(sp.N(_R7.subs(_x, R("1.1")))) != 7, "演習7 右端の値は極限ではない")
_a7 = ("DNE", 5, 7)

# 8 s(t) = 30t − 5t²
_s = 30 * _t - 5 * _t ** 2
_av8 = sp.simplify((_s.subs(_t, 2 + _d) - _s.subs(_t, 2)) / _d)
eq(_av8, 10 - 5 * _d, "演習8 平均の速さは 10 − 5Δ")
chk(_s.subs(_t, 2) == 40, "演習8 s(2) = 40")
eq(sp.expand(_s.subs(_t, 2 + _d)), 40 + 10 * _d - 5 * _d ** 2, "演習8 s(2+Δ) の展開")
chk(sp.limit(_av8, _d, 0) == 10, "演習8 極限は 10")
for _v, _want in (("-0.1", "10.5"), ("-0.01", "10.05"),
                  ("0.01", "9.95"), ("0.1", "9.5")):
    chk(sp.nsimplify(sp.N(_av8.subs(_d, R(_v)), 12)) == sp.Rational(_want),
        "演習8 表 Δ = %s は %s" % (_v, _want))
    in_text("$%s$" % _want, "演習8 表の値")
# ★ Δ = 0 はもとの式では 0/0（約分できたのは Δ ≠ 0 だから）
chk((_s.subs(_t, 2 + _d) - _s.subs(_t, 2)).subs(_d, 0) == 0, "演習8 分子は Δ = 0 で 0")
# 誤答側: 導関数を使わずに s(2)/2 のような量と取りちがえていないか
chk(sp.limit(_av8, _d, 0) != _s.subs(_t, 2), "演習8 速さ 10 と高さ 40 は別もの")
_a8 = 10

# 9 kx+1 / x²−5
_e9L, _e9R = _k * _x + 1, _x ** 2 - 5
_kv = sp.solve(sp.Eq(_e9L.subs(_x, 3), _e9R.subs(_x, 3)), _k)
chk(_kv == [1], "演習9 k = 1")
chk(_e9R.subs(_x, 3) == 4, "演習9 右側極限は 4")
chk(_e9L.subs({_x: 3, _k: 1}) == 4, "演習9 k = 1 なら左側も 4")
chk(_e9L.subs({_x: 3, _k: 2}) == 7, "演習9 k = 2 なら左側は 7")
chk(_e9L.subs({_x: 3, _k: 2}) != _e9R.subs(_x, 3), "演習9 k = 2 では極限がない")
# k を動かすと左側だけが動く（右側は k を含まない）
chk(_k not in _e9R.free_symbols, "演習9 右側は k によらない")
_a9 = 1

# 10 (x²−4)/(x−2)
_e10 = (_x ** 2 - 4) / (_x - 2)
eq(sp.factor(_x ** 2 - 4), (_x + 2) * (_x - 2), "演習10 因数分解")
eq(sp.expand((_x + 2) * (_x - 2)), _x ** 2 - 4, "演習10 展開して戻る")
chk(sp.limit(_e10, _x, 2) == 4, "演習10 極限は 4")
chk(sp.N((_x + 2).subs(_x, R("1.999"))) == 3.999, "演習10 x = 1.999 で 3.999")
chk(sp.N((_x + 2).subs(_x, R("2.001"))) == 4.001, "演習10 x = 2.001 で 4.001")
# ★ 0/0 は「存在しない」ことを示さない: 同じ 0/0 でも極限はさまざま
chk(sp.limit((_x ** 2 - 4) / (_x - 2), _x, 2) == 4, "演習10 0/0 でも極限は 4")
chk(sp.limit((_x - 2) / (_x ** 2 - 4), _x, 2) == R(1, 4), "演習10 別の 0/0 は 1/4")
chk(sp.limit(sp.Abs(_x - 2) / (_x - 2), _x, 2, "+")
    != sp.limit(sp.Abs(_x - 2) / (_x - 2), _x, 2, "-"),
    "演習10 0/0 で存在しない例もある（だから 0/0 だけでは決まらない）")
_a10 = 4

# 答えの重複がないこと
_ans = [_a1, str(_a2), _a4, _a5, _a6, _a7, _a8, _a9, _a10]
chk(len(set(map(str, _ans))) == len(_ans), "演習の答えが重複していない: %s" % (_ans,))

# ══════════════════════════════════════════════════════════
# 6. 本文が例題・演習の答えを先に見せていないこと
# ══════════════════════════════════════════════════════════
_body = TEXT[:TEXT.index("\n## Worked examples")]
for _leak in ("0.693", "1.099", "1.098", "10 - 5\\Delta", "6.97", "4.999",
              "10000", "3k + 1", "0.9801"):
    chk(_leak not in _body, "本文が答えを先に見せている: " + _leak)

# ══════════════════════════════════════════════════════════
# 構成
# ══════════════════════════════════════════════════════════
_tips = re.findall(r"::: \{\.callout-tip collapse=\"true\"\}\n## (.+)", TEXT)
_gdc = [h for h in _tips
        if not h.startswith("解説") and h != "クリックすると開きます"]
chk(len(_gdc) == 1, "電卓の折りたたみは 1 つ: %s" % _gdc)
for _h in _gdc:
    chk(_h.startswith("Section I Part B と Section II Part A では"),
        "電卓の見出しが Section I Part B で始まる: " + _h)
chk("## Using your GDC" not in TEXT, "独立した GDC の節は置いていない")
in_text("**Section I Part A と Section II Part B では使えません。**",
        "電卓が使えない区分を明記")
for _m in ["Casio", "fx-CG50", "TI-84", "OPTN", "PRB", "cSolve", "nDeriv"]:
    not_in_text(_m, "他機種・確かめていない機能: " + _m)
for _m in ["Paper 1", "Paper 2", "IB ", "GDC"]:
    not_in_text(_m, "IB の言いまわしが残っている: " + _m)
not_in_text("## 参考：この項目のシラバス（原文）", "末尾のシラバスは置かない")
# ★ 決めごと（_AP-BC-PLAN.md）: dx は斜体、逆三角は \arctan
not_in_text("\\mathrm{d}", "dx は斜体に統一（\\mathrm{d} を使わない）")
not_in_text("\\tan^{-1}", "逆三角関数は \\arctan に統一")
# ★ このページの CED Topic 1.1–1.4・1.9 は AB と共通なので BC の印は付けない
not_in_text("**BC only**", "このページは BC 限定ではない")
in_text("**このページが扱う CED Topic：1.1・1.2・1.3・1.4・1.9**", "CED Topic の明記")

chk(len([l for l in TEXT.splitlines() if l.rstrip() == "---"]) == 6, "--- は 6 本")
chk(TEXT.count('<details class="jp-trans">') == 14, "日本語訳が 14")
chk(TEXT.count("</details>") == 14, "</details> も 14")
chk(TEXT.count("{.ex-sep}") == 9, "ex-sep が 9")
chk(TEXT.count("{.ex-no}") == 10, "演習が 10")
chk(TEXT.count("{.model-answer}") == 4, "model-answer が 4")
chk(len(re.findall(r"^::: \{#exm-apbc11-", TEXT, re.M)) == 4, "例題が 4")
chk(TEXT.count("## 解答例（答案用紙に書くこと）") == 14, "解答例が 14")
_h2 = re.findall(r"^## (.+)$", TEXT, re.M)
_want = ["The idea", "Why it works", "Worked examples", "Common errors",
         "Exercises"]
chk([h for h in _h2 if h in _want] == _want, "5 つの見出しが所定の順")
_nums = [int(_v) for _v in re.findall(r"^### (\d+)\. ", TEXT, re.M)]
chk(_nums == list(range(1, len(_nums) + 1)) and 5 <= len(_nums) <= 7,
    "The idea が 1.. の連番（5〜7 節）: %s" % _nums)
chk(TEXT.count("**検算") >= 12, "検算が十分ある: %d" % TEXT.count("**検算"))
not_in_text("**確かめ", "検算は「検算」で統一")
for word in ["誰でもできる", "簡単です", "当然", "明らか", "もちろん",
             "当たり前", "そのとおり"]:
    not_in_text(word, "禁止語")
_ce = TEXT[TEXT.index("\n## Common errors"):TEXT.index("\n## Exercises")]
chk(_ce.count("::: {.callout-warning}") == 6, "Common errors が 6 つ")
# ★ AP の答案作法（引き継ぎ §6.3）を Common errors に必ず 1 つ入れる
chk(("Justify" in _ce or "Explain" in _ce)
    and ("単位" in _ce or "途中の式" in _ce or "根拠" in _ce),
    "Common errors に AP の答案作法がある")
_MASKED = TEXT.replace("\\$", "")
for _blk in re.findall(r"\$\$(.*?)\$\$", _MASKED, re.S):
    chk("✓" not in _blk and "✗" not in _blk, "表示数式に ✓/✗: " + _blk[:40])
for _blk in re.findall(r"(?<!\$)\$([^$\n]+)\$(?!\$)", _MASKED):
    chk("✓" not in _blk and "✗" not in _blk, "インライン数式に ✓/✗: " + _blk[:40])
chk(all("@eq-" not in TEXT.split("$$")[i] for i in range(1, len(TEXT.split("$$")), 2)),
    "表示数式の中に @-ref がない")
for _blk in re.findall(r"::: \{\.model-answer\}(.*?):::", TEXT, re.S):
    chk(not re.search(r"[ぁ-んァ-ン一-龥]",
                      _blk.replace("**試験ではこう書く**", "")),
        "model-answer に日本語")
_anchors = set(re.findall(r"\{#([a-z0-9-]+)\}", TEXT))
for _a0 in set(re.findall(r"\]\(#([a-z0-9-]+)\)", TEXT)):
    chk(_a0 in _anchors or _a0 in {"why-it-works", "common-errors", "exercises"},
        "ページ内リンク先がない: #" + _a0)
for _r0 in set(re.findall(r"@(?:exm|eq|fig|tbl)-([a-z0-9]+)-", TEXT)):
    chk(_r0 == "apbc11", "他ページの @-ref: " + _r0)
for _href in re.findall(r"\]\(([^)]+\.qmd[^)]*)\)", TEXT):
    chk(os.path.exists(os.path.normpath(os.path.join(
        os.path.dirname(QMD), _href.split("#")[0]))),
        "リンク先のページがない: " + _href)
_head = TEXT[:TEXT.index("## The idea")]
chk(_head.count("::: {.callout-note}") == 1 and _head.count(":::") == 2,
    "冒頭の callout は 1 つだけ")
not_in_text("**この節ですること：", "節の頭の 1 文は置かない")
not_in_text("\\vec{", "ベクトルの記号は太字")
chk(len(re.findall(r"^::: ", TEXT, re.M)) == len(re.findall(r"^:::$", TEXT, re.M)),
    "::: の開閉が一致")
for _h in re.findall(r"^#{1,4} .+$", TEXT, re.M):
    chk(not re.search(r"\$\s*—", _h), "見出しで数式の直後に —: " + _h)
_i = TEXT.index(chr(10) + "## Why it works" + chr(10))
_j = TEXT.index(chr(10) + "## Worked examples", _i)
_wiw = TEXT[_i:_j]
chk('collapse="true"}' + chr(10) + "## クリックすると開きます" in _wiw,
    "Why it works は折りたたんである")
chk(_wiw.rstrip().endswith(":::"), "折りたたみが閉じてある")
# ★ The idea の見出しは「英語（日本語）」の形
for _hh in re.findall(r"^### \d+\. (.+?) \{#", TEXT, re.M):
    chk(_hh.endswith("）") and "（" in _hh,
        "見出しが 英語（日本語） の形でない: " + _hh)
    chk(re.match(r"[A-Za-z$]", _hh) is not None,
        "見出しが英語で始まっていない: " + _hh)
    _en = _hh[:_hh.rindex("（")]
    chk(not re.search(r"[ぁ-んァ-ヶ一-龥]", _en),
        "見出しの英語の側に日本語がある: " + _hh)

# ══════════════════════════════════════════════════════════
# 図
# ══════════════════════════════════════════════════════════
for _n in ("a", "b"):
    _p = os.path.join(BASE, "img", "apbc-1-1-idea-%s.svg" % _n)
    chk(os.path.exists(_p), "図 (%s) がある" % _n)
    chk("](img/apbc-1-1-idea-%s.svg)" % _n in TEXT,
        "本文が図 (%s) を貼っている" % _n)
for _s0 in glob.glob(os.path.join(BASE, "img", "*.png")):
    chk(False, "PNG が残っている: " + os.path.basename(_s0))
for bad in ["pmatrix", "\\lvert", "\\rvert"]:
    chk(bad not in FIGCODE, "図で使えない記法: " + bad)
chk(not re.search(r"[ぁ-んァ-ン]", FIGSTR), "図のラベルに日本語がない")
in_fig("the limit at $x = 2$ is $3$, even though $f(2) = 1$", "図 (a) の見出し")
in_fig("no point of the graph here", "図 (a) の白丸の説明")
in_fig("three ways a limit can fail to exist", "図 (b) の見出し")
for _w in ("left and right disagree", "grows without bound", "keeps oscillating"):
    in_fig('"%s"' % _w, "図 (b) の見出し: " + _w)
# ★ 図の数値が本文と合っているか（図は極限 3・値 1 を示している）
chk("0.5 * _seg ** 2 + 1" in FIGCODE, "図 (a) の関数は 0.5x²+1")
chk(sp.Rational(1, 2) * 2 ** 2 + 1 == 3, "図 (a) は x = 2 で 3")
in_text("\\lim_{x \\to 2} f(x) = 3, \\qquad f(2) = 1", "本文が図と同じ値を書いている")
# ★ 図が例題・演習の答えを載せていないこと
for _leak in ("0.693", "1.099", "9.5", "10.05", "1.098"):
    chk(_leak not in FIGSTR, "図のラベルが答えを載せている: " + _leak)

# ══════════════════════════════════════════════════════════
# 登録
# ══════════════════════════════════════════════════════════
DRAFT = open(os.path.join(ROOT, "_quarto-draft.yml"), encoding="utf-8").read()
chk("ap-bc/01-limits/apbc-1-1.qmd" in DRAFT, "draft に登録")
PUB = open(os.path.join(ROOT, "_quarto.yml"), encoding="utf-8").read()
chk("ap-bc" not in PUB, "公開用には入れない")
chk("G-LQBB7M9VZ0" not in PUB, "IB の本の測定 ID を流用していない")
IDX = open(os.path.join(ROOT, "ap-bc", "index.qmd"), encoding="utf-8").read()
chk("(01-limits/apbc-1-1.qmd)" in IDX, "index にある")
_written = sorted(glob.glob(os.path.join(ROOT, "ap-bc", "*", "apbc-*.qmd")))
chk(len(re.findall(r"^\| \*\*Unit [0-9.]+\*\* \|.*✅", IDX, re.M)) == len(_written),
    "✅ の数とページ数が合う")
_mm = re.search(r"いまのところ (\d+) ページです（全 (\d+) ページ）", IDX)
chk(_mm is not None and int(_mm.group(1)) == len(_written), "「いまのところ N」")
chk(_mm is not None and int(_mm.group(2)) == 45, "全 45 ページ")
_rows = re.findall(r"^\| \*\*Unit [0-9.]+\*\* \|", IDX, re.M)
chk(len(_rows) == 45, "一覧表の行が 45: %d" % len(_rows))
# ★ 試験の形（CED の Exam Information、Effective Fall 2020）
for _row in ["| **I** Part A | 選択式 | $29$ | $35\\%$ | $62$ 分 | **不可** |",
             "| **I** Part B | 選択式 | $13$ | $15\\%$ | $38$ 分 | **必要** |",
             "| **II** Part A | 記述式 | $2$ | $16.7\\%$ | $30$ 分 | **必要** |",
             "| **II** Part B | 記述式 | $4$ | $33.3\\%$ | $60$ 分 | **不可** |"]:
    chk(_row in IDX, "index の試験の形: " + _row)
chk(29 + 13 == 42 and 2 + 4 == 6, "選択 42 問・記述 6 問")
chk(abs(35 + 15 - 50) < 1e-9 and abs(16.7 + 33.3 - 50) < 1e-9, "配点は 50% ずつ")
chk(62 + 38 + 30 + 60 == 190, "合計 190 分 = 3 時間 10 分")
in_text("**Section I Part A と Section II Part B では使えません。**",
        "電卓が使えない区分（試験の形と一致）")

PLAN = open(os.path.join(ROOT, "_AP-BC-PLAN.md"), encoding="utf-8").read()
_pm = re.search(r"\*\*進捗：(\d+) / 45 ページ。\*\*", PLAN)
chk(_pm is not None and int(_pm.group(1)) == len(_written), "PLAN の進捗")
GLO = open(os.path.join(ROOT, "glossary-ap.qmd"), encoding="utf-8").read()
for t in ["| limit |", "| one-sided limit |", "| left-hand limit |",
          "| right-hand limit |", "| does not exist |", "| indeterminate form |",
          "| average rate of change |", "| instantaneous rate of change |"]:
    chk(t in GLO, "対訳表にある: " + t)
# ★ .gitignore が College Board の PDF を止めているか
GI = open(os.path.join(ROOT, ".gitignore"), encoding="utf-8").read()
chk(re.search(r"^\*\.pdf$", GI, re.M) is not None, ".gitignore に *.pdf がある")

# ══════════════════════════════════════════════════════════
# 見張り
# ══════════════════════════════════════════════════════════
in_text("## $f(a)$ を計算して、それを極限にする", "f(a) と極限の取りちがえ")
in_text("## 表の値を、そのまま答えとして書く", "表は見積もり")
in_text("## 片側だけを調べて「極限がある」と書く", "片側だけ")
in_text("## $\\infty$ を「極限の値」として書く", "∞ は値ではない")
in_text("## 結論だけ書いて、根拠を言葉で書かない", "AP の答案作法")
in_text("## $\\lim$ の下の $x \\to a$ を書かない", "記号を略さない")
in_text("**肩の $-$ と $+$ は、符号ではありません。**", "肩の記号の注意")
in_text("**「$x = a$ を代入する」ではありません。**", "代入ではない")
in_text("$3$ 桁の小数", "小数第 3 位")
in_text("**DNE** と略して書いてかまいません。", "DNE の書き方")
in_text("次のページ Unit 1.2 で扱います", "前方参照はリンクにしない")

# ── CED（Course and Exam Description）からの逐語引用 ──────
# ★ 要約しないこと。直したら、PDF の該当ページで取り直すこと。
in_text("> Given a function $f$, the limit of $f(x)$ as $x$ approaches $c$ is a real "
        "number $R$ if $f(x)$ can be made arbitrarily close to $R$ by taking $x$ "
        "sufficiently close to $c$ (but not equal to $c$).",
        "CED LIM-1.A.1 の定義（逐語）")
in_text("> The epsilon-delta definition of a limit is not assessed on the "
        "AP Calculus AB or BC Exam.", "CED の除外（ε-δ は問われない）")
in_text("> Because of issues of scale, graphical representations of functions may "
        "miss important function behavior.", "CED LIM-1.C.3（グラフは見落とす）")
in_text("> For free-response questions, when results are obtained using one of these "
        "required calculator capabilities, students are required to write the setup",
        "CED の setup を書く規則")
in_text("typically rounding or truncating to three places after the decimal point",
        "CED の丸めの規則")
in_text("*Constructing a table of values to conjecture a limit*",
        "CED が挙げる電卓の使い方")
# ★ CED が「典型的に」と書いているので、断定しない
in_text("切り捨てでもかまいません。問題文に指定があれば、そちらに従います。",
        "丸めは断定しない")
not_in_text("必ず小数第 $3$ 位", "丸めを断定していない")
# ★ CED に無い言い方を書いていないこと
for _m in ["hybrid", "digital format", "AB subscore"]:
    not_in_text(_m, "CED で裏の取れていない記述: " + _m)
not_in_text("](apbc-1-2.qmd", "まだ無いページにリンクしていない")
not_in_text("](../", "他ページへのリンクを張っていない")

print()
print("OK", OK, "/ NG", NG)
sys.exit(1 if NG else 0)
