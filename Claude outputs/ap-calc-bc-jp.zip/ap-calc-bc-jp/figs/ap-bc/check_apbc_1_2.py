"""AP Calculus BC Unit 1.2 — Finding limits algebraically and the squeeze theorem を検算する。

    python3 figs/ap-bc/check_apbc_1_2.py
"""
import glob
import os
import re
import sys

import sympy as sp

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
BASE = os.path.join(ROOT, "ap-bc", "01-limits")
QMD = os.path.join(BASE, "apbc-1-2.qmd")
TEXT = open(QMD, encoding="utf-8").read()
FIG = open(os.path.join(HERE, "make_apbc_1_2.py"), encoding="utf-8").read()
_NODOC = re.sub(r'"""(?:.|\n)*?"""', "", FIG)
FIGSTR = "\n".join(t for t in re.findall(r'r?"((?:[^"\\]|\\.)*)"', _NODOC)
                   if not t.startswith("#") and (" " in t or "$" in t))
FIGCODE = FIG.split('"""', 2)[-1]

OK = NG = 0


def chk(cond, msg):
    global OK, NG
    if cond:
        OK += 1
    else:
        NG += 1
        print("NG :", msg)


def eq(u, v, msg=""):
    chk(sp.simplify(sp.expand(u) - sp.expand(v)) == 0, msg + "  (%s vs %s)" % (u, v))


def in_text(sub, msg=""):
    chk(sub in TEXT, "本文に見つからない: " + msg + " :: " + sub[:70])


def not_in_text(sub, msg=""):
    chk(sub not in TEXT, "本文に残っている: " + msg + " :: " + sub[:70])


def in_fig(sub, msg=""):
    chk(sub in FIG, "図のスクリプトに見つからない: " + msg + " :: " + sub[:70])

_x, _k = sp.symbols("x k", real=True)
R = sp.Rational


def nv(expr, val, n=12):
    return sp.N(expr.subs(_x, R(val)), n)


# ══════════════════════════════════════════════════════════
# 0. The idea（第 1〜6 節の数値）
# ══════════════════════════════════════════════════════════
# 第 1 節 極限の性質
_f, _g = _x ** 2, 3 * _x
chk(sp.limit(_f + _g + 1, _x, 2) == 11, "第 1 節 x²+3x+1 の極限は 11")
chk(sp.limit(_f, _x, 2) == 4 and sp.limit(_g, _x, 2) == 6, "第 1 節 4 と 6 に分けられる")
chk(sp.limit(_f, _x, 2) + sp.limit(_g, _x, 2) + 1 == sp.limit(_f + _g + 1, _x, 2),
    "第 1 節 和の性質")
chk("%.4f" % float(nv(_f + _g + 1, "1.99", 20)) == "10.9301",
    "第 1 節 x = 1.99 で 10.9301")
in_text("$1.99^{2} + 3(1.99) + 1 = 10.9301$", "第 1 節 検算の値")
# 積の性質も確かめる（誤答側: 和で代用すると値がちがう）
chk(sp.limit(_f * _g, _x, 2) == 24, "第 1 節 積の性質")
chk(sp.limit(_f * _g, _x, 2) != sp.limit(_f + _g, _x, 2), "第 1 節 積と和はちがう")

# 第 2 節 代入
_s2 = (_x ** 2 + 2) / (_x - 1)
chk(sp.limit(_s2, _x, 4) == 6, "第 2 節 代入して 6")
chk((_x - 1).subs(_x, 4) == 3, "第 2 節 分母の極限は 3（0 ではない）")
chk("%.4f" % float(nv(_s2, "4.01")) == "6.0067", "第 2 節 x = 4.01 の値")
in_text("$\\dfrac{16.0801 + 2}{3.01} = 6.0066\\ldots$", "第 2 節 検算の値")

# 第 3 節 因数分解
_s3 = (_x ** 2 - 16) / (_x - 4)
eq(sp.factor(_x ** 2 - 16), (_x + 4) * (_x - 4), "第 3 節 因数分解")
eq(sp.expand((_x + 4) * (_x - 4)), _x ** 2 - 16, "第 3 節 展開して戻る")
chk(sp.limit(_s3, _x, 4) == 8, "第 3 節 極限は 8")
chk("%.3f" % float(nv(_x + 4, "3.999", 20)) == "7.999"
    and "%.3f" % float(nv(_x + 4, "4.001", 20)) == "8.001", "第 3 節 両側の値")
# ★ 約分前と後は「同じ関数ではない」: x = 4 での定義がちがう
chk(sp.denom(sp.together(_s3)).subs(_x, 4) == 0, "第 3 節 約分前は x = 4 で未定義")

# 第 4 節 共役
_s4 = (sp.sqrt(4 + _x) - 2) / _x
eq(sp.expand((sp.sqrt(4 + _x) - 2) * (sp.sqrt(4 + _x) + 2)), _x, "第 4 節 共役の積は x")
chk(sp.limit(_s4, _x, 0) == R(1, 4), "第 4 節 極限は 1/4")
chk(sp.simplify(_s4 - 1 / (sp.sqrt(4 + _x) + 2)) == 0, "第 4 節 書きかえが等しい")
# 誤答側: 分母を展開してしまうと x が約分できない形になる
chk(sp.expand(_x * (sp.sqrt(4 + _x) + 2)) != _x * (sp.sqrt(4 + _x) + 2)
    or True, "第 4 節 分母は積の形で残す")

# 第 5 節 絶対値
_s5 = (3 * _x - 12) / sp.Abs(_x - 4)
chk(sp.limit(_s5, _x, 4, "-") == -3, "第 5 節 左側は -3")
chk(sp.limit(_s5, _x, 4, "+") == 3, "第 5 節 右側は 3")
chk(sp.limit(_s5, _x, 4, "-") != sp.limit(_s5, _x, 4, "+"), "第 5 節 極限は存在しない")
eq(3 * _x - 12, 3 * (_x - 4), "第 5 節 3x-12 = 3(x-4)")

# 第 6 節 はさみうち
chk(sp.limit(_x ** 2 * sp.sin(1 / _x), _x, 0) == 0, "第 6 節 x² sin(1/x) の極限は 0")
chk(sp.limit(-_x ** 2, _x, 0) == 0 and sp.limit(_x ** 2, _x, 0) == 0,
    "第 6 節 外側は両方とも 0")
# ★ sin(1/x) 単独では極限がない（はさみうちが効いている証拠）
chk(sp.limit(sp.sin(1 / _x), _x, 0) != 0, "第 6 節 sin(1/x) 単独では決まらない")
for _v in ("0.01", "0.003", "0.12345"):
    _val = float(nv(_x ** 2 * sp.sin(1 / _x), _v, 20))
    chk(abs(_val) <= float(nv(_x ** 2, _v, 20)) + 1e-18,
        "第 6 節 x = %s ではさまれている" % _v)
chk(sp.limit(sp.sin(_x) / _x, _x, 0) == 1, "第 6 節 sin x / x は 1")
chk(sp.limit((1 - sp.cos(_x)) / _x, _x, 0) == 0, "第 6 節 (1-cos x)/x は 0")
chk(sp.limit(sp.sin(3 * _x) / _x, _x, 0) == 3, "第 6 節 sin 3x / x は 3")
# ★ 本文は切り捨てで 2.99999… と書いている（四捨五入すると 3.00000）
_v6 = float(sp.N(sp.sin(R("0.003")) / R("0.001"), 20))
chk(2.99999 <= _v6 < 3, "第 6 節 x = 0.001 の値は 2.99999… (%s)" % _v6)
in_text("$\\dfrac{\\sin 0.003}{0.001} = 2.99999\\ldots$", "第 6 節 検算の値")

# ══════════════════════════════════════════════════════════
# 1. 例題
# ══════════════════════════════════════════════════════════
# 例題1 (x²+5x+6)/(x+2)
_m1 = (_x ** 2 + 5 * _x + 6) / (_x + 2)
eq(sp.factor(_x ** 2 + 5 * _x + 6), (_x + 2) * (_x + 3), "例題1 因数分解")
eq(sp.expand((_x + 2) * (_x + 3)), _x ** 2 + 5 * _x + 6, "例題1 展開して戻る")
chk(sp.limit(_m1, _x, -2) == 1, "例題1 極限は 1")
chk((_x ** 2 + 5 * _x + 6).subs(_x, -2) == 0, "例題1 分子は 0")
chk("%.3f" % float(nv(_x + 3, "-2.001", 20)) == "0.999"
    and "%.3f" % float(nv(_x + 3, "-1.999", 20)) == "1.001", "例題1 両側の値")

# 例題2 (√(x+2)-3)/(x-7)
_m2 = (sp.sqrt(_x + 2) - 3) / (_x - 7)
eq(sp.expand((sp.sqrt(_x + 2) - 3) * (sp.sqrt(_x + 2) + 3)), _x - 7,
   "例題2 共役の積は x-7")
chk(sp.limit(_m2, _x, 7) == R(1, 6), "例題2 極限は 1/6")
chk("%.5f" % float(nv(_m2, "7.1", 20)) == "0.16621", "例題2 x = 7.1 の値")
in_text("$\\dfrac{1}{\\sqrt{9.1}+3} = 0.16620\\ldots$", "例題2 検算の値")
chk(float(nv(_m2, "7.1", 20)) < float(R(1, 6)), "例題2 1/6 のすぐ下")

# 例題3 sin 4x / (2x)
_m3 = sp.sin(4 * _x) / (2 * _x)
chk(sp.limit(_m3, _x, 0) == 2, "例題3 極限は 2")
eq(sp.Rational(4, 2), 2, "例題3 係数は 2")
chk("%.5f" % float(sp.N(sp.sin(R("0.004")) / R("0.002"), 20)) == "1.99999",
    "例題3 x = 0.001 の値")
# 誤答側: 中の角を無視して 1 と答えると合わない
chk(sp.limit(_m3, _x, 0) != 1, "例題3 角を無視すると 1 になってしまう")

# 例題4 はさみうち 6x-9 ≤ g ≤ x²
chk(sp.limit(6 * _x - 9, _x, 3) == 9, "例題4 下の極限は 9")
chk(sp.limit(_x ** 2, _x, 3) == 9, "例題4 上の極限は 9")
eq(sp.factor(_x ** 2 - (6 * _x - 9)), (_x - 3) ** 2, "例題4 差は (x-3)²")
chk(sp.solve(sp.Eq(_x ** 2 - (6 * _x - 9), 0), _x) == [3], "例題4 等号は x = 3 だけ")
for _v in ("0", "1.5", "3", "5", "-2"):
    chk(float(nv(_x ** 2 - 6 * _x + 9, _v, 20)) >= 0, "例題4 x = %s で不等式が成り立つ" % _v)

# ══════════════════════════════════════════════════════════
# 2. 演習
# ══════════════════════════════════════════════════════════
_e1 = (_x ** 2 - 25) / (_x - 5)
eq(sp.factor(_x ** 2 - 25), (_x + 5) * (_x - 5), "演習1 因数分解")
chk(sp.limit(_e1, _x, 5) == 10, "演習1 極限は 10")
chk("%.3f" % float(nv(_x + 5, "4.999", 20)) == "9.999"
    and "%.3f" % float(nv(_x + 5, "5.001", 20)) == "10.001", "演習1 両側の値")
_a1 = 10

_e2 = (_x ** 2 - 3 * _x + 2) / (_x ** 2 - 1)
eq(sp.factor(_x ** 2 - 3 * _x + 2), (_x - 1) * (_x - 2), "演習2 分子の因数分解")
eq(sp.factor(_x ** 2 - 1), (_x - 1) * (_x + 1), "演習2 分母の因数分解")
chk(sp.limit(_e2, _x, 1) == R(-1, 2), "演習2 極限は -1/2")
chk((_x + 1).subs(_x, 1) == 2, "演習2 約分後の分母は 0 でない")
chk("%.4f" % float(nv((_x - 2) / (_x + 1), "1.001", 20)) == "-0.4993",
    "演習2 x = 1.001 の値")
_a2 = R(-1, 2)

_e3 = (sp.sqrt(_x + 16) - 4) / _x
eq(sp.expand((sp.sqrt(_x + 16) - 4) * (sp.sqrt(_x + 16) + 4)), _x, "演習3 共役の積は x")
chk(sp.limit(_e3, _x, 0) == R(1, 8), "演習3 極限は 1/8")
chk("%.5f" % float(nv(_e3, "0.1", 20)) == "0.12481", "演習3 x = 0.1 の値")
in_text("$\\dfrac{1}{\\sqrt{16.1}+4} = 0.12480\\ldots$", "演習3 検算の値")
chk(float(nv(_e3, "0.1", 20)) < 0.125, "演習3 1/8 のすぐ下")
_a3 = R(1, 8)

_e4 = (3 * _x ** 2 - _x + 4) / (_x + 5)
chk(sp.limit(_e4, _x, 2) == 2, "演習4 極限は 2")
chk((_x + 5).subs(_x, 2) == 7, "演習4 分母の極限は 7（0 ではない）")
chk("%.4f" % float(nv(3 * _x ** 2 - _x + 4, "2.01", 20)) == "14.1103",
    "演習4 x = 2.01 の分子")
chk("%.4f" % float(nv(_e4, "2.01", 20)) == "2.0129", "演習4 x = 2.01 の値")
chk("%.4f" % float(nv(_e4, "2.001", 20)) == "2.0013", "演習4 x = 2.001 の値")
in_text("$\\dfrac{14.1103}{7.01} = 2.0128\\ldots$", "演習4 検算の値")
_a4 = 2

_e5 = (_x ** 2 - 4) / sp.Abs(_x - 2)
chk(sp.limit(_e5, _x, 2, "+") == 4, "演習5 右側は 4")
chk(sp.limit(_e5, _x, 2, "-") == -4, "演習5 左側は -4")
chk("%.2f" % float(nv(_e5, "2.1", 20)) == "4.10"
    and "%.2f" % float(nv(_e5, "1.9", 20)) == "-3.90", "演習5 値の確認")
chk(float(nv(_e5, "2.001", 20)) - float(nv(_e5, "1.999", 20)) > 7.9,
    "演習5 差は縮まない")
_a5 = ("DNE", -4, 4)

chk(sp.limit(5 - _x ** 2, _x, 0) == 5 and sp.limit(5 + _x ** 2, _x, 0) == 5,
    "演習6 外側は両方とも 5")
chk("%.4f" % float(nv(2 * _x ** 2, "0.1", 20)) == "0.0200", "演習6 x = 0.1 の幅は 0.02")
chk("%.6f" % float(nv(2 * _x ** 2, "0.01", 20)) == "0.000200",
    "演習6 x = 0.01 の幅は 0.0002")
_a6 = 5

_e7 = sp.sin(7 * _x) / (2 * _x)
chk(sp.limit(_e7, _x, 0) == R(7, 2), "演習7 極限は 7/2")
chk("%.5f" % float(sp.N(sp.sin(R("0.007")) / R("0.002"), 20)) == "3.49997",
    "演習7 x = 0.001 の値")
_a7 = R(7, 2)

_e8 = (_x ** 2 + _k * _x - 12) / (_x - 3)
chk(sp.solve(sp.Eq((_x ** 2 + _k * _x - 12).subs(_x, 3), 0), _k) == [1], "演習8 k = 1")
eq(sp.factor((_x ** 2 + _x - 12)), (_x + 4) * (_x - 3), "演習8 k=1 の因数分解")
chk(sp.limit(_e8.subs(_k, 1), _x, 3) == 7, "演習8 極限は 7")
# ★ ほかの k では分子が 0 に行かない
for _kv in (0, 2, -3):
    chk((_x ** 2 + _kv * _x - 12).subs(_x, 3) != 0, "演習8 k = %d では分子が 0 でない" % _kv)
chk("%.1f" % float(nv((_x ** 2 + 2 * _x - 12) / (_x - 3), "3.001", 20)) == "3008.0",
    "演習8 k=2, x=3.001 の値")
chk("%.1f" % float(nv((_x ** 2 + 2 * _x - 12) / (_x - 3), "2.999", 20)) == "-2992.0",
    "演習8 k=2, x=2.999 の値")
in_text("$x = 3.001$ なら $3008.0\\ldots$、$x = 2.999$ なら $-2992.0\\ldots$",
        "演習8 検算の値")
_a8 = (1, 7)

_e9 = _x * sp.cos(1 / _x)
chk(sp.limit(_e9, _x, 0) == 0, "演習9 極限は 0")
chk(sp.limit(-sp.Abs(_x), _x, 0) == 0 and sp.limit(sp.Abs(_x), _x, 0) == 0,
    "演習9 外側は両方とも 0")
for _v in ("0.01", "0.2", "-0.05"):
    chk(abs(float(nv(_e9, _v, 20))) <= abs(float(R(_v))) + 1e-18,
        "演習9 x = %s ではさまれている" % _v)
# ★ cos(1/x) 単独では極限がない
chk(sp.limit(sp.cos(1 / _x), _x, 0) != 0, "演習9 cos(1/x) 単独では決まらない")
_a9 = 0

_e10 = (_x ** 2 - 7 * _x + 12) / (_x - 4)
eq(sp.factor(_x ** 2 - 7 * _x + 12), (_x - 3) * (_x - 4), "演習10 因数分解")
chk(sp.limit(_e10, _x, 4) == 1, "演習10 極限は 1")
# ★ 同じ 0/0 でも値はちがう（生徒の理由づけが成り立たない）
chk(sp.limit(2 * (_x - 4) / (_x ** 2 - 7 * _x + 12), _x, 4) == 2,
    "演習10 同じ形で値が 2 になる例")
chk(sp.simplify(2 * (_x - 4) / (_x ** 2 - 7 * _x + 12) - 2 / (_x - 3)) == 0,
    "演習10 その式は 2/(x-3)")
chk((2 * (_x - 4)).subs(_x, 4) == 0 and (_x ** 2 - 7 * _x + 12).subs(_x, 4) == 0,
    "演習10 その式も 0/0 の形")
_a10 = 1

# 答えの重複がないこと
_ans = [_a1, _a2, _a3, _a4, _a5, _a6, _a7, _a8, _a9, _a10]
chk(len(set(map(str, _ans))) == len(_ans), "演習の答えが重複していない: %s" % (_ans,))

# ══════════════════════════════════════════════════════════
# 本文が例題・演習の答えを先に見せていないこと
# ══════════════════════════════════════════════════════════
_body = TEXT[:TEXT.index("\n## Worked examples")]
for _leak in ("= 10$", "-\\frac{1}{2}", "\\frac{1}{8}", "\\frac{7}{2}",
              "\\sqrt{x+16}", "\\sin 7x", "\\sin 4x", "6x - 9",
              "5 - x^{2}", "x\\cos", "x^{2}+5x+6", "\\sqrt{x+2}"):
    chk(_leak not in _body, "本文が答えを先に見せている: " + _leak)
# ══════════════════════════════════════════════════════════
# 構成
# ══════════════════════════════════════════════════════════
_tips = re.findall(r"::: \{\.callout-tip collapse=\"true\"\}\n## (.+)", TEXT)
_gdc = [h for h in _tips
        if not h.startswith("解説") and h != "クリックすると開きます"]
chk(len(_gdc) == 1, "電卓の折りたたみは 1 つ: %s" % _gdc)
for _h in _gdc:
    chk(_h.startswith("Section I Part B と Section II Part A では"),
        "電卓の見出しが Section I Part B で始まる: " + _h)
chk("## Using your GDC" not in TEXT, "独立した GDC の節は置いていない")
in_text("**Section I Part A と Section II Part B では使えません。**",
        "電卓が使えない区分を明記")
for _m in ["Casio", "fx-CG50", "TI-84", "OPTN", "PRB", "cSolve", "nDeriv"]:
    not_in_text(_m, "他機種・確かめていない機能: " + _m)
for _m in ["Paper 1", "Paper 2", "IB ", "GDC"]:
    not_in_text(_m, "IB の言いまわしが残っている: " + _m)
not_in_text("## 参考：この項目のシラバス（原文）", "末尾のシラバスは置かない")
# ★ 決めごと（_AP-BC-PLAN.md）: dx は斜体、逆三角は \arctan
not_in_text("\\mathrm{d}", "dx は斜体に統一（\\mathrm{d} を使わない）")
not_in_text("\\tan^{-1}", "逆三角関数は \\arctan に統一")
chk(len([l for l in TEXT.splitlines() if l.rstrip() == "---"]) == 6, "--- は 6 本")
chk(TEXT.count('<details class="jp-trans">') == 14, "日本語訳が 14")
chk(TEXT.count("</details>") == 14, "</details> も 14")
chk(TEXT.count("{.ex-sep}") == 9, "ex-sep が 9")
chk(TEXT.count("{.ex-no}") == 10, "演習が 10")
chk(TEXT.count("{.model-answer}") == 4, "model-answer が 4")
chk(len(re.findall(r"^::: \{#exm-apbc12-", TEXT, re.M)) == 4, "例題が 4")
chk(TEXT.count("## 解答例（答案用紙に書くこと）") == 14, "解答例が 14")
_h2 = re.findall(r"^## (.+)$", TEXT, re.M)
_want = ["The idea", "Why it works", "Worked examples", "Common errors",
         "Exercises"]
chk([h for h in _h2 if h in _want] == _want, "5 つの見出しが所定の順")
_nums = [int(_v) for _v in re.findall(r"^### (\d+)\. ", TEXT, re.M)]
chk(_nums == list(range(1, len(_nums) + 1)) and 5 <= len(_nums) <= 7,
    "The idea が 1.. の連番（5〜7 節）: %s" % _nums)
chk(TEXT.count("**検算") >= 12, "検算が十分ある: %d" % TEXT.count("**検算"))
not_in_text("**確かめ", "検算は「検算」で統一")
for word in ["誰でもできる", "簡単です", "当然", "明らか", "もちろん",
             "当たり前", "そのとおり"]:
    not_in_text(word, "禁止語")
_ce = TEXT[TEXT.index("\n## Common errors"):TEXT.index("\n## Exercises")]
chk(_ce.count("::: {.callout-warning}") == 6, "Common errors が 6 つ")
# ★ AP の答案作法（引き継ぎ §6.3）を Common errors に必ず 1 つ入れる
chk(("Justify" in _ce or "Explain" in _ce)
    and ("単位" in _ce or "途中の式" in _ce or "根拠" in _ce),
    "Common errors に AP の答案作法がある")
_MASKED = TEXT.replace("\\$", "")
for _blk in re.findall(r"\$\$(.*?)\$\$", _MASKED, re.S):
    chk("✓" not in _blk and "✗" not in _blk, "表示数式に ✓/✗: " + _blk[:40])
for _blk in re.findall(r"(?<!\$)\$([^$\n]+)\$(?!\$)", _MASKED):
    chk("✓" not in _blk and "✗" not in _blk, "インライン数式に ✓/✗: " + _blk[:40])
chk(all("@eq-" not in TEXT.split("$$")[i] for i in range(1, len(TEXT.split("$$")), 2)),
    "表示数式の中に @-ref がない")
for _blk in re.findall(r"::: \{\.model-answer\}(.*?):::", TEXT, re.S):
    chk(not re.search(r"[ぁ-んァ-ン一-龥]",
                      _blk.replace("**試験ではこう書く**", "")),
        "model-answer に日本語")
_anchors = set(re.findall(r"\{#([a-z0-9-]+)\}", TEXT))
for _a0 in set(re.findall(r"\]\(#([a-z0-9-]+)\)", TEXT)):
    chk(_a0 in _anchors or _a0 in {"why-it-works", "common-errors", "exercises"},
        "ページ内リンク先がない: #" + _a0)
for _r0 in set(re.findall(r"@(?:exm|eq|fig|tbl)-([a-z0-9]+)-", TEXT)):
    chk(_r0 == "apbc12", "他ページの @-ref: " + _r0)
for _href in re.findall(r"\]\(([^)]+\.qmd[^)]*)\)", TEXT):
    chk(os.path.exists(os.path.normpath(os.path.join(
        os.path.dirname(QMD), _href.split("#")[0]))),
        "リンク先のページがない: " + _href)
_head = TEXT[:TEXT.index("## The idea")]
chk(_head.count("::: {.callout-note}") == 1 and _head.count(":::") == 2,
    "冒頭の callout は 1 つだけ")
not_in_text("**この節ですること：", "節の頭の 1 文は置かない")
not_in_text("\\vec{", "ベクトルの記号は太字")
chk(len(re.findall(r"^::: ", TEXT, re.M)) == len(re.findall(r"^:::$", TEXT, re.M)),
    "::: の開閉が一致")
for _h in re.findall(r"^#{1,4} .+$", TEXT, re.M):
    chk(not re.search(r"\$\s*—", _h), "見出しで数式の直後に —: " + _h)
_i = TEXT.index(chr(10) + "## Why it works" + chr(10))
_j = TEXT.index(chr(10) + "## Worked examples", _i)
_wiw = TEXT[_i:_j]
chk('collapse="true"}' + chr(10) + "## クリックすると開きます" in _wiw,
    "Why it works は折りたたんである")
chk(_wiw.rstrip().endswith(":::"), "折りたたみが閉じてある")
# ★ The idea の見出しは「英語（日本語）」の形
for _hh in re.findall(r"^### \d+\. (.+?) \{#", TEXT, re.M):
    chk(_hh.endswith("）") and "（" in _hh,
        "見出しが 英語（日本語） の形でない: " + _hh)
    chk(re.match(r"[A-Za-z$]", _hh) is not None,
        "見出しが英語で始まっていない: " + _hh)
    _en = _hh[:_hh.rindex("（")]
    chk(not re.search(r"[ぁ-んァ-ヶ一-龥]", _en),
        "見出しの英語の側に日本語がある: " + _hh)

# ══════════════════════════════════════════════════════════
# 図
# ══════════════════════════════════════════════════════════
for _n in ("a", "b"):
    _p = os.path.join(BASE, "img", "apbc-1-2-idea-%s.svg" % _n)
    chk(os.path.exists(_p), "図 (%s) がある" % _n)
    chk("](img/apbc-1-2-idea-%s.svg)" % _n in TEXT,
        "本文が図 (%s) を貼っている" % _n)
for _s0 in glob.glob(os.path.join(BASE, "img", "*.png")):
    chk(False, "PNG が残っている: " + os.path.basename(_s0))
for bad in ["pmatrix", "\\lvert", "\\rvert"]:
    chk(bad not in FIGCODE, "図で使えない記法: " + bad)
chk(not re.search(r"[ぁ-んァ-ン]", FIGSTR), "図のラベルに日本語がない")
# ★ ここに、このページ固有の図の検査を書いてください。
#    図の見出しとラベルを in_fig で逐語に押さえ、図の数値が本文と
#    合っていること、図が例題・演習の答えを載せていないことを見ます。
#    見本: figs/ap-bc/check_apbc_1_2.py

# ══════════════════════════════════════════════════════════
# 登録
# ══════════════════════════════════════════════════════════
DRAFT = open(os.path.join(ROOT, "_quarto-draft.yml"), encoding="utf-8").read()
chk("ap-bc/01-limits/apbc-1-2.qmd" in DRAFT, "draft に登録")
PUB = open(os.path.join(ROOT, "_quarto.yml"), encoding="utf-8").read()
chk("ap-bc" not in PUB, "公開用には入れない")
chk("G-LQBB7M9VZ0" not in PUB, "IB の本の測定 ID を流用していない")
IDX = open(os.path.join(ROOT, "ap-bc", "index.qmd"), encoding="utf-8").read()
chk("(01-limits/apbc-1-2.qmd)" in IDX, "index にある")
_written = sorted(glob.glob(os.path.join(ROOT, "ap-bc", "*", "apbc-*.qmd")))
chk(len(re.findall(r"^\| \*\*Unit [0-9.]+\*\* \|.*✅", IDX, re.M)) == len(_written),
    "✅ の数とページ数が合う")
_mm = re.search(r"いまのところ (\d+) ページです（全 (\d+) ページ）", IDX)
chk(_mm is not None and int(_mm.group(1)) == len(_written), "「いまのところ N」")
chk(_mm is not None and int(_mm.group(2)) == 45, "全 45 ページ")
_rows = re.findall(r"^\| \*\*Unit [0-9.]+\*\* \|", IDX, re.M)
chk(len(_rows) == 45, "一覧表の行が 45: %d" % len(_rows))
PLAN = open(os.path.join(ROOT, "_AP-BC-PLAN.md"), encoding="utf-8").read()
_pm = re.search(r"\*\*進捗：(\d+) / 45 ページ。\*\*", PLAN)
chk(_pm is not None and int(_pm.group(1)) == len(_written), "PLAN の進捗")
GLO = open(os.path.join(ROOT, "glossary-ap.qmd"), encoding="utf-8").read()
for t in ["| limit |", "| one-sided limit |", "| left-hand limit |",
          "| right-hand limit |", "| does not exist |", "| indeterminate form |",
          "| average rate of change |", "| instantaneous rate of change |"]:
    chk(t in GLO, "対訳表にある: " + t)
# ★ .gitignore が College Board の PDF を止めているか
GI = open(os.path.join(ROOT, ".gitignore"), encoding="utf-8").read()
chk(re.search(r"^\*\.pdf$", GI, re.M) is not None, ".gitignore に *.pdf がある")


# ══════════════════════════════════════════════════════════
# ページ固有: CED の逐語引用と、見張り
# ══════════════════════════════════════════════════════════
in_text("**このページが扱う CED Topic：1.5・1.6・1.7・1.8**", "CED Topic の明記")
# ★ CED Topic 1.5–1.8 は AB と共通なので、BC の印は付けない
not_in_text("**BC only**", "このページは BC 限定ではない")

# CED からの逐語引用（要約しないこと。直したら PDF で取り直すこと）
in_text("> Limits of sums, differences, products, quotients, and composite "
        "functions can be found using limit theorems.", "CED LIM-1.D.2")
in_text("> Factoring and dividing common factors of rational functions",
        "CED 1.6 の例（因数分解）")
in_text("> Multiplying by an expression involving the conjugate of a sum or "
        "difference in order to simplify functions involving radicals",
        "CED 1.6 の例（共役）")
in_text("> One-sided limits can be determined analytically or graphically.",
        "CED LIM-1.D.1")
in_text("> The squeeze theorem can be used to show "
        "$\\lim_{x \\to 0}\\dfrac{\\sin x}{x} = 1$ and "
        "$\\lim_{x \\to 0}\\dfrac{1-\\cos x}{x} = 0$.", "CED 1.8 の例")
in_text("> It may be necessary or helpful to rearrange expressions into "
        "equivalent forms before evaluating limits.", "CED LIM-1.E.1")

# 本文の言い切りの見張り
in_text("@eq-apbc12-quotient が使えるのは $M \\neq 0$ のときだけです", "商の条件")
in_text("**代入して値が出るなら、それ以上の変形は要りません。**", "まず代入")
in_text("**分母はかけ戻さないでください。**", "共役のあとの注意")
in_text("**絶対値を見たら、中身の符号で場合分けです。**", "絶対値の注意")
in_text("**条件を $2$ つとも確かめてください。**", "はさみうちの条件")
in_text("Unit 1.4 で扱います", "前方参照は文章で")
not_in_text("](apbc-1-3.qmd", "まだ無いページにリンクしていない")
not_in_text("](apbc-1-4.qmd", "まだ無いページにリンクしていない")
# ★ 書いたページ（Unit 1.1）へのリンクは、ファイルもアンカーも実在すること
in_text("[Unit 1.1 第 2 節](apbc-1-1.qmd#notation)", "Unit 1.1 へのリンク")
_prev = open(os.path.join(BASE, "apbc-1-1.qmd"), encoding="utf-8").read()
chk("{#notation}" in _prev, "リンク先の Unit 1.1 に #notation がある")
chk(_prev.count("### 2. ") == 1 and "### 2. Limit notation" in _prev,
    "Unit 1.1 の第 2 節が notation で合っている")

# Common errors に AP の答案作法が入っていること（引き継ぎ §6.3）
in_text("## はさみうちで、条件の確認を書かない", "justification の誤り")
in_text("## 途中の式を残さず、答えだけ書く", "setup を見せる")

# ══════════════════════════════════════════════════════════
# 図
# ══════════════════════════════════════════════════════════
in_fig("the two outer curves meet at $0$, so the middle one has to go there too",
       "図 (a) の見出し")
in_fig("all three go to $0$", "図 (a) の説明")
in_fig("start by substituting, and only rewrite when you have to", "図 (b) の見出し")
for _w in ("substitute $x = a$", "a number\\ncomes out", "factor and\\ncancel",
           "multiply by the\\nconjugate", "use a known\\ntrig limit",
           "take the two sides\\nseparately"):
    in_fig('"%s"' % _w, "図 (b) の箱: " + _w)
in_fig("use the squeeze theorem", "図 (b) の下の一行")
# ★ 図 (a) が描いているのは、本文と同じ x² sin(1/x)
chk("t ** 2 * np.sin(1 / t)" in FIGCODE, "図 (a) は x² sin(1/x)")
in_text("$f(x) = x^{2}\\sin\\left(\\dfrac{1}{x}\\right)$", "本文も同じ関数")
# ★ 図が例題・演習の答えを載せていないこと
for _leak in ("1/6", "7/2", "1/8", "= 9", "= 7"):
    chk(_leak not in FIGSTR, "図のラベルが答えを載せている: " + _leak)

# ══════════════════════════════════════════════════════════
# 用語集（このページで初出の語）
# ══════════════════════════════════════════════════════════
for t in ["| limit theorem", "| squeeze theorem |", "| conjugate |",
          "| factor |"]:
    chk(t in GLO, "対訳表にある: " + t)

print()
print("OK", OK, "/ NG", NG)
sys.exit(1 if NG else 0)
