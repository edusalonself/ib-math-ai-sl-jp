"""Unit 1.1（Limits: reading them from graphs and tables）の図をつくる。

    python3 figs/ap-bc/make_apbc_1_1.py            … SVG だけ
    FIG_PNG=1 python3 figs/ap-bc/make_apbc_1_1.py  … 目視用の PNG も

出力: ap-bc/01-limits/img/apbc-1-1-idea-a.svg
      ap-bc/01-limits/img/apbc-1-1-idea-b.svg

(a) x = 2 で穴があいたグラフ。極限は 3、f(2) は 1。
(b) 極限が存在しない 3 つの形（左右がちがう・限りなく大きくなる・振動する）。

matplotlib の mathtext には次の制限があります（tools/README.md）。
  * \\begin{pmatrix} は読めない → 使わない
  * \\lvert \\rvert も読めない → | を使う
  * 日本語のグリフがない → ラベルはすべて英語

★ 図に例題・演習の答えを書かないこと。
★ PNG は目視用です。確認が終わったら消してください。
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "..", "ap-bc", "01-limits", "img")
os.makedirs(OUT, exist_ok=True)

INK = "#1f2328"
ACCENT = "#0f766e"
GREY = "#6b7280"
WARM = "#b45309"
GREEN = "#4d7c0f"

# ══════════════════════════════════════════════════════════
# (a) 穴のあいたグラフ
# ══════════════════════════════════════════════════════════
fig1, ax1 = plt.subplots(figsize=(5.8, 3.6))
ax1.set_title("the limit at $x = 2$ is $3$, even though $f(2) = 1$",
              fontsize=10.5, color=INK, loc="left", pad=10)

xl = np.linspace(-0.4, 2.0, 400)
xr = np.linspace(2.0, 2.9, 400)
for _seg in (xl, xr):
    ax1.plot(_seg, 0.5 * _seg ** 2 + 1, color=INK, linewidth=2.2, zorder=4)

ax1.plot([2], [3], marker="o", markersize=8, markerfacecolor="white",
         markeredgecolor=INK, markeredgewidth=1.8, zorder=6)
ax1.plot([2], [1], marker="o", markersize=7, color=INK, zorder=6)

ax1.plot([0, 2], [3, 3], color=ACCENT, linewidth=1.0,
         linestyle=(0, (4, 3)), zorder=2)
ax1.plot([2, 2], [0, 3], color=ACCENT, linewidth=1.0,
         linestyle=(0, (4, 3)), zorder=2)

ax1.annotate("", xy=(1.88, 0.30), xytext=(1.10, 0.30),
             arrowprops=dict(arrowstyle="-|>", color=WARM, linewidth=1.4))
ax1.annotate("", xy=(2.12, 0.30), xytext=(2.90, 0.30),
             arrowprops=dict(arrowstyle="-|>", color=WARM, linewidth=1.4))
ax1.text(1.42, 0.52, "$x \\to 2$", fontsize=9, color=WARM)

ax1.text(3.30, 4.90, "$y = f(x)$", fontsize=10, color=INK)
ax1.text(3.30, 3.70, "from both sides,\nthe values approach $3$",
         fontsize=9, color=WARM)
ax1.text(3.30, 2.50, "open circle:\nno point of the graph here",
         fontsize=9, color=GREY)
ax1.text(3.30, 1.30, "the graph does have\na point at $(2,\\ 1)$",
         fontsize=9, color=INK)

ax1.set_xlim(-0.6, 6.9)
ax1.set_ylim(-0.1, 5.4)
ax1.set_xticks([2])
ax1.set_xticklabels(["$2$"])
ax1.set_yticks([1, 3])
ax1.set_yticklabels(["$1$", "$3$"])
ax1.spines["top"].set_visible(False)
ax1.spines["right"].set_visible(False)
ax1.tick_params(labelsize=9, colors=GREY)

# ══════════════════════════════════════════════════════════
# (b) 極限が存在しない 3 つの形
# ══════════════════════════════════════════════════════════
fig2, axs = plt.subplots(1, 3, figsize=(7.6, 2.7))
fig2.suptitle("three ways a limit can fail to exist", fontsize=10.5,
              color=INK, x=0.02, ha="left")

axA, axB, axC = axs

# 左右がちがう
tA1 = np.linspace(-1.6, -0.02, 200)
tA2 = np.linspace(0.02, 1.6, 200)
axA.plot(tA1, np.sign(tA1), color=ACCENT, linewidth=2.0)
axA.plot(tA2, np.sign(tA2), color=ACCENT, linewidth=2.0)
axA.plot([0], [-1], marker="o", markersize=6, markerfacecolor="white",
         markeredgecolor=ACCENT, markeredgewidth=1.5)
axA.plot([0], [1], marker="o", markersize=6, markerfacecolor="white",
         markeredgecolor=ACCENT, markeredgewidth=1.5)
axA.set_title("left and right disagree", fontsize=9.5, color=GREY, pad=6)
axA.set_xlabel(r"$y = \frac{|x|}{x}$   at $x = 0$", fontsize=9.5, color=INK,
               labelpad=8)
axA.set_xlim(-1.8, 1.8)
axA.set_ylim(-1.8, 1.8)

# 限りなく大きくなる
tB1 = np.linspace(-1.6, -0.22, 300)
tB2 = np.linspace(0.22, 1.6, 300)
for _t in (tB1, tB2):
    axB.plot(_t, 1 / _t ** 2, color=WARM, linewidth=2.0)
axB.set_title("grows without bound", fontsize=9.5, color=GREY, pad=6)
axB.set_xlabel(r"$y = \frac{1}{x^{2}}$   at $x = 0$", fontsize=9.5, color=INK,
               labelpad=8)
axB.set_xlim(-1.8, 1.8)
axB.set_ylim(-2.0, 21.0)

# 振動する
tC = np.linspace(0.012, 0.6, 4000)
tC = np.concatenate((-tC[::-1], tC))
axC.plot(tC, np.sin(1 / tC), color=GREEN, linewidth=0.9)
axC.set_title("keeps oscillating", fontsize=9.5, color=GREY, pad=6)
axC.set_xlabel(r"$y = \sin\left(\frac{1}{x}\right)$   at $x = 0$",
               fontsize=9.5, color=INK, labelpad=8)
axC.set_xlim(-0.65, 0.65)
axC.set_ylim(-1.5, 1.5)

for _ax in axs:
    _ax.axhline(0, color=GREY, linewidth=0.7, zorder=0)
    _ax.axvline(0, color=GREY, linewidth=0.7, zorder=0)
    _ax.set_xticks([])
    _ax.set_yticks([])
    for _s in ("top", "right", "left", "bottom"):
        _ax.spines[_s].set_visible(False)

for _fig, _name in ((fig1, "a"), (fig2, "b")):
    _fig.tight_layout()
    _fig.savefig(os.path.join(OUT, "apbc-1-1-idea-%s.svg" % _name),
                 format="svg", bbox_inches="tight")
    if os.environ.get("FIG_PNG"):
        _fig.savefig(os.path.join(OUT, "apbc-1-1-idea-%s.png" % _name),
                     format="png", dpi=150, bbox_inches="tight")
print("wrote", OUT)
