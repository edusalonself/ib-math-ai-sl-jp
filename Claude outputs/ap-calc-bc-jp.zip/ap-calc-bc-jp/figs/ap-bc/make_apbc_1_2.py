"""Unit 1.2（Finding limits algebraically and the squeeze theorem）の図をつくる。

    python3 figs/ap-bc/make_apbc_1_2.py            … SVG だけ
    FIG_PNG=1 python3 figs/ap-bc/make_apbc_1_2.py  … 目視用の PNG も

出力: ap-bc/01-limits/img/apbc-1-2-idea-a.svg
      ap-bc/01-limits/img/apbc-1-2-idea-b.svg

(a) はさみうちの原理。y = x^2 sin(1/x) を y = x^2 と y = -x^2 ではさむ。
(b) 極限を求めるときの、手順の選び方。

matplotlib の mathtext には次の制限があります（tools/README.md）。
  * \\begin{pmatrix} は読めない → 使わない
  * \\lvert \\rvert も読めない → | を使う
  * 日本語のグリフがない → ラベルはすべて英語

★ 図に例題・演習の答えを書かないこと。
★ PNG は目視用です。確認が終わったら消してください。
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "..", "ap-bc", "01-limits", "img")
os.makedirs(OUT, exist_ok=True)

INK = "#1f2328"
ACCENT = "#0f766e"
GREY = "#6b7280"
WARM = "#b45309"
OLIVE = "#4d7c0f"

# ══════════════════════════════════════════════════════════
# (a) はさみうちの原理
# ══════════════════════════════════════════════════════════
fig1, ax1 = plt.subplots(figsize=(5.8, 3.4))
ax1.set_title("the two outer curves meet at $0$, so the middle one has to go there too",
              fontsize=10, color=INK, loc="left", pad=10)

t = np.linspace(-0.62, 0.62, 6000)
t = t[np.abs(t) > 1e-4]
ax1.plot(t, t ** 2, color=WARM, linewidth=1.8, label="upper")
ax1.plot(t, -t ** 2, color=OLIVE, linewidth=1.8, label="lower")
ax1.plot(t, t ** 2 * np.sin(1 / t), color=ACCENT, linewidth=1.1)
ax1.plot([0], [0], marker="o", markersize=5.5, color=INK, zorder=6)

ax1.text(0.66, 0.375, "$y = x^{2}$", fontsize=9.5, color=WARM)
ax1.text(0.66, -0.425, "$y = -x^{2}$", fontsize=9.5, color=OLIVE)
ax1.text(0.66, 0.04, "$y = x^{2}\\sin\\left(\\frac{1}{x}\\right)$",
         fontsize=9.5, color=ACCENT)
ax1.text(0.66, -0.20, "all three go to $0$\nas $x$ goes to $0$", fontsize=9,
         color=GREY)

ax1.set_xlim(-0.72, 1.55)
ax1.set_ylim(-0.50, 0.50)
ax1.axhline(0, color=GREY, linewidth=0.7, zorder=0)
ax1.axvline(0, color=GREY, linewidth=0.7, zorder=0)
ax1.set_xticks([0])
ax1.set_xticklabels(["$0$"])
ax1.set_yticks([])
for _s in ("top", "right", "left"):
    ax1.spines[_s].set_visible(False)
ax1.spines["bottom"].set_visible(False)
ax1.tick_params(labelsize=9, colors=GREY)

# ══════════════════════════════════════════════════════════
# (b) 手順の選び方
# ══════════════════════════════════════════════════════════
fig2, ax2 = plt.subplots(figsize=(7.2, 3.6))
ax2.set_title("start by substituting, and only rewrite when you have to",
              fontsize=10, color=INK, loc="left", pad=10)


def box(x, y, w, h, text, col, fs=9.0):
    ax2.add_patch(FancyBboxPatch((x, y), w, h,
                                 boxstyle="round,pad=0.10,rounding_size=0.12",
                                 facecolor="white", edgecolor=col,
                                 linewidth=1.4, zorder=2))
    ax2.text(x + w / 2, y + h / 2, text, fontsize=fs, color=INK,
             ha="center", va="center", zorder=3)


def link(p, q, col=GREY):
    ax2.annotate("", xy=q, xytext=p,
                 arrowprops=dict(arrowstyle="-|>", color=col, linewidth=1.3,
                                 shrinkA=4, shrinkB=4))


box(3.6, 5.0, 3.4, 0.85, "substitute $x = a$", ACCENT, fs=9.8)

box(0.2, 3.3, 2.7, 0.85, "a number\ncomes out", OLIVE, fs=9.0)
box(3.2, 3.3, 3.1, 0.85, "the rule changes\nat $x = a$", GREY, fs=9.0)
box(6.8, 3.3, 3.4, 0.85, "$\\frac{0}{0}$ comes out", WARM, fs=9.0)
link((4.6, 5.0), (1.55, 4.15))
link((5.3, 5.0), (4.75, 4.15))
link((6.3, 5.0), (8.5, 4.15))

box(0.2, 1.5, 2.7, 0.8, "that is\nthe limit", GREY, fs=8.8)
box(3.2, 1.5, 3.1, 0.8, "take the two sides\nseparately", GREY, fs=8.8)
box(6.7, 1.5, 2.1, 0.8, "factor and\ncancel", GREY, fs=8.8)
box(9.1, 1.5, 2.1, 0.8, "multiply by the\nconjugate", GREY, fs=8.8)
box(11.5, 1.5, 2.1, 0.8, "use a known\ntrig limit", GREY, fs=8.8)
link((1.55, 3.3), (1.55, 2.3))
link((4.75, 3.3), (4.75, 2.3))
for _cx in (7.75, 10.15, 12.55):
    link((8.5, 3.3), (_cx, 2.3))

ax2.text(0.2, 0.55, "trapped between two functions with the same limit?"
         "  use the squeeze theorem", fontsize=9, color=ACCENT)
ax2.set_xlim(-0.2, 13.9)
ax2.set_ylim(0.1, 6.3)
ax2.axis("off")

for _fig, _name in ((fig1, "a"), (fig2, "b")):
    _fig.tight_layout()
    _fig.savefig(os.path.join(OUT, "apbc-1-2-idea-%s.svg" % _name),
                 format="svg", bbox_inches="tight")
    if os.environ.get("FIG_PNG"):
        _fig.savefig(os.path.join(OUT, "apbc-1-2-idea-%s.png" % _name),
                     format="png", dpi=150, bbox_inches="tight")
print("wrote", OUT)
