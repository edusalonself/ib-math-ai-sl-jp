"""AP Calculus BC Unit 1.3 — Continuity, discontinuities and the Intermediate Value Theorem を検算する。

    python3 figs/ap-bc/check_apbc_1_3.py
"""
import glob
import os
import re
import sys

import sympy as sp

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
BASE = os.path.join(ROOT, "ap-bc", "01-limits")
QMD = os.path.join(BASE, "apbc-1-3.qmd")
TEXT = open(QMD, encoding="utf-8").read()
FIG = open(os.path.join(HERE, "make_apbc_1_3.py"), encoding="utf-8").read()
_NODOC = re.sub(r'"""(?:.|\n)*?"""', "", FIG)
FIGSTR = "\n".join(t for t in re.findall(r'r?"((?:[^"\\]|\\.)*)"', _NODOC)
                   if not t.startswith("#") and (" " in t or "$" in t))
FIGCODE = FIG.split('"""', 2)[-1]

OK = NG = 0


def chk(cond, msg):
    global OK, NG
    if cond:
        OK += 1
    else:
        NG += 1
        print("NG :", msg)


def eq(u, v, msg=""):
    chk(sp.simplify(sp.expand(u) - sp.expand(v)) == 0, msg + "  (%s vs %s)" % (u, v))


def in_text(sub, msg=""):
    chk(sub in TEXT, "本文に見つからない: " + msg + " :: " + sub[:70])


def not_in_text(sub, msg=""):
    chk(sub not in TEXT, "本文に残っている: " + msg + " :: " + sub[:70])


def in_fig(sub, msg=""):
    chk(sub in FIG, "図のスクリプトに見つからない: " + msg + " :: " + sub[:70])

_x, _a, _k = sp.symbols("x a k", real=True)
R = sp.Rational


def nv(expr, val, n=20):
    return float(sp.N(expr.subs(_x, R(val)), n))


def s4(expr, val, fmt="%.4f"):
    return fmt % nv(expr, val)


# ══════════════════════════════════════════════════════════
# 0. The idea
# ══════════════════════════════════════════════════════════
# 第 1 節 連続の 3 条件（f(x) = x²+1 は x = 2 で連続）
_f1 = _x ** 2 + 1
chk(_f1.subs(_x, 2) == 5, "第 1 節 f(2) = 5")
chk(sp.limit(_f1, _x, 2) == 5, "第 1 節 極限も 5")
chk(sp.limit(_f1, _x, 2) == _f1.subs(_x, 2), "第 1 節 3 つ目の条件")
chk(s4(_f1, "1.999", "%.6f") == "4.996001", "第 1 節 x = 1.999 の値")
chk(s4(_f1, "2.001", "%.6f") == "5.004001", "第 1 節 x = 2.001 の値")
in_text("$x = 1.999$ なら $4.996001$、$x = 2.001$ なら $5.004001$", "第 1 節 検算の値")

# 第 3 節 有理式の定義域
_f3 = (_x + 1) / ((_x - 2) * (_x + 3))
chk(sorted(sp.solve((_x - 2) * (_x + 3), _x)) == [-3, 2], "第 3 節 分母の零点")
eq(sp.expand((_x - 2) * (_x + 3)), _x ** 2 + _x - 6, "第 3 節 展開すると x²+x-6")
chk(sp.limit(_f3, _x, 2, "+") in (sp.oo, -sp.oo), "第 3 節 x = 2 で発散")
chk(sp.limit(_f3, _x, 0) == R(-1, 6), "第 3 節 定義域の中では値がある")

# 第 4 節 removable の作り方
_g4 = (_x ** 2 - 1) / (_x - 1)
eq(sp.factor(_x ** 2 - 1), (_x + 1) * (_x - 1), "第 4 節 因数分解")
chk(sp.limit(_g4, _x, 1) == 2, "第 4 節 極限は 2")
chk(sp.denom(sp.together(_g4)).subs(_x, 1) == 0, "第 4 節 x = 1 では未定義")
# ★ 値を決め直した関数は、本当に 3 条件を満たす
_g4fix = _x + 1
chk(_g4fix.subs(_x, 1) == 2 and sp.limit(_g4fix, _x, 1) == 2, "第 4 節 決め直すと連続")

# 第 5 節 場合分けの境目
_b = sp.Symbol("b")
chk(sp.solve(sp.Eq(3 * 1 + _b, 1 ** 2 - 2), _b) == [-4], "第 5 節 b = -4")
chk((_x ** 2 - 2).subs(_x, 1) == -1, "第 5 節 右の式の値は -1")
chk((3 * _x - 4).subs(_x, 1) == -1, "第 5 節 b = -4 なら左も -1")
# ★ b がちがうと段ができる
chk((3 * _x + 0).subs(_x, 1) != (_x ** 2 - 2).subs(_x, 1), "第 5 節 b = 0 では段ができる")

# 第 6 節 IVT の例
_f6 = _x ** 3 + _x - 1
chk(_f6.subs(_x, 0) == -1 and _f6.subs(_x, 1) == 1, "第 6 節 端の値は -1 と 1")
chk(_f6.subs(_x, 0) < 0 < _f6.subs(_x, 1), "第 6 節 0 はそのあいだ")
chk(s4(_f6, "0.6", "%.3f") == "-0.184", "第 6 節 f(0.6) = -0.184")
chk(s4(_f6, "0.7", "%.3f") == "0.043", "第 6 節 f(0.7) = 0.043")
in_text("$f(0.6) = 0.216+0.6-1 = -0.184$", "第 6 節 検算の値")
chk(0.6 < float(sp.nsolve(_f6, 0.7)) < 0.7, "第 6 節 根は 0.6 と 0.7 のあいだ")
# ★ 多項式は連続（CED LIM-2.B.2）なので IVT が使える
chk(sp.limit(_f6, _x, R("0.5")) == _f6.subs(_x, R("0.5")), "第 6 節 多項式は連続")

# Why it works の反例（段のある関数は d を飛びこす）
chk(1 != 3, "Why 段の左右は 1 と 3")
chk(not (1 == 2 or 3 == 2), "Why この関数は 2 を取らない")

# ══════════════════════════════════════════════════════════
# 1. 例題
# ══════════════════════════════════════════════════════════
# 例題1 jump
_L, _Rr = _x ** 2 - 1, 2 * _x + 1
chk(_Rr.subs(_x, 3) == 7, "例題1 f(3) = 7")
chk(_L.subs(_x, 3) == 8, "例題1 左側は 8")
chk(_L.subs(_x, 3) != _Rr.subs(_x, 3), "例題1 極限は存在しない")
chk(s4(_L, "2.999", "%.6f") == "7.994001", "例題1 x = 2.999 の値")
chk(s4(_Rr, "3.001", "%.3f") == "7.002", "例題1 x = 3.001 の値")
# ★ 値を決め直しても直らない（極限がない）
chk(_L.subs(_x, 3) != R("7.5") or _Rr.subs(_x, 3) != R("7.5"),
    "例題1 どんな値でも両側には合わない")

# 例題2 removable と vertical asymptote
_f2 = (_x - 2) / ((_x - 2) * (_x + 4))
chk(sp.simplify(_f2 - 1 / (_x + 4)) == 0, "例題2 約分すると 1/(x+4)")
chk(sp.limit(_f2, _x, 2) == R(1, 6), "例題2 x = 2 の極限は 1/6")
chk(sp.limit(_f2, _x, -4, "+") in (sp.oo, -sp.oo), "例題2 x = -4 で発散")
chk(sp.limit(_f2, _x, -4, "-") != sp.limit(_f2, _x, -4, "+"), "例題2 左右で符号がちがう")
chk(s4(1 / (_x + 4), "1.999", "%.5f") == "0.16669", "例題2 x = 1.999 の値")
# ★ 本文は切り捨てで 0.16663… と書いている（四捨五入すると 0.16664）
_v2 = nv(1 / (_x + 4), "2.001")
chk(0.16663 <= _v2 < 0.16664, "例題2 x = 2.001 の値は 0.16663… (%s)" % _v2)
chk(s4(1 / (_x + 4), "-3.99", "%.1f") == "100.0", "例題2 x = -3.99 の値")
chk(s4(1 / (_x + 4), "-4.01", "%.1f") == "-100.0", "例題2 x = -4.01 の値")

# 例題3 removable を直す
_h3 = (_x ** 2 + 3 * _x - 10) / (_x - 2)
eq(sp.factor(_x ** 2 + 3 * _x - 10), (_x - 2) * (_x + 5), "例題3 因数分解")
eq(sp.expand((_x + 5) * (_x - 2)), _x ** 2 + 3 * _x - 10, "例題3 展開して戻る")
chk(sp.limit(_h3, _x, 2) == 7, "例題3 極限は 7")
chk(s4(_x + 5, "1.999", "%.3f") == "6.999", "例題3 x = 1.999 の値")
chk(s4(_x + 5, "2.001", "%.3f") == "7.001", "例題3 x = 2.001 の値")

# 例題4 IVT（d = 4 が -3 と 7 のあいだ）
chk(-3 < 4 < 7, "例題4 4 は -3 と 7 のあいだ")
chk(not (-3 < 9 < 7), "例題4 9 はあいだではない（誤答側）")

# ══════════════════════════════════════════════════════════
# 2. 演習
# ══════════════════════════════════════════════════════════
# 1 連続
_e1L, _e1R = 2 * _x + 1, 4 - _x
chk(_e1L.subs(_x, 1) == 3 and _e1R.subs(_x, 1) == 3, "演習1 両側とも 3")
chk(s4(_e1L, "0.999", "%.3f") == "2.998", "演習1 x = 0.999 の値")
chk(s4(_e1R, "1.001", "%.3f") == "2.999", "演習1 x = 1.001 の値")
_a1 = ("continuous", 3)

# 2 removable, 極限 6
_e2 = (_x ** 2 - 9) / (_x - 3)
eq(sp.factor(_x ** 2 - 9), (_x + 3) * (_x - 3), "演習2 因数分解")
chk(sp.limit(_e2, _x, 3) == 6, "演習2 極限は 6")
chk(s4(_x + 3, "2.999", "%.3f") == "5.999" and s4(_x + 3, "3.001", "%.3f") == "6.001",
    "演習2 両側の値")
_a2 = ("removable", 6)

# 3 k = 3
_e3 = (_x ** 2 - 5 * _x + 4) / (_x - 4)
eq(sp.factor(_x ** 2 - 5 * _x + 4), (_x - 1) * (_x - 4), "演習3 因数分解")
chk(sp.limit(_e3, _x, 4) == 3, "演習3 極限は 3")
chk(s4(_x - 1, "3.999", "%.3f") == "2.999" and s4(_x - 1, "4.001", "%.3f") == "3.001",
    "演習3 両側の値")
chk(sp.limit(_e3, _x, 4) != 5, "演習3 k = 5 では合わない")
_a3 = 3

# 4 removable と vertical asymptote
_e4 = (_x + 3) / (_x ** 2 - 9)
eq(sp.factor(_x ** 2 - 9), (_x + 3) * (_x - 3), "演習4 分母の因数分解")
chk(sp.simplify(_e4 - 1 / (_x - 3)) == 0, "演習4 約分すると 1/(x-3)")
chk(sp.limit(_e4, _x, -3) == R(-1, 6), "演習4 x = -3 の極限は -1/6")
chk(sp.limit(_e4, _x, 3, "+") in (sp.oo, -sp.oo), "演習4 x = 3 で発散")
chk(s4(1 / (_x - 3), "-2.999", "%.5f") == "-0.16669", "演習4 x = -2.999 の値")
chk(s4(1 / (_x - 3), "3.001", "%.1f") == "1000.0", "演習4 x = 3.001 の値")
chk(s4(1 / (_x - 3), "2.999", "%.1f") == "-1000.0", "演習4 x = 2.999 の値")
_a4 = ("removable", R(-1, 6), "asymptote")

# 5 連続な区間
_e5 = (_x + 2) / (_x ** 2 - _x - 6)
eq(sp.factor(_x ** 2 - _x - 6), (_x - 3) * (_x + 2), "演習5 因数分解")
chk(sorted(sp.solve(_x ** 2 - _x - 6, _x)) == [-2, 3], "演習5 分母の零点は -2 と 3")
chk(sp.simplify(_e5 - 1 / (_x - 3)) == 0, "演習5 約分すると 1/(x-3)")
_a5 = "intervals"

# 6 a = -1
chk(sp.solve(sp.Eq(2 * 3 + _a, 3 ** 2 - 4), _a) == [-1], "演習6 a = -1")
chk((_x ** 2 - 4).subs(_x, 3) == 5, "演習6 右の式は 5")
chk((2 * _x - 1).subs(_x, 3) == 5, "演習6 a = -1 なら左も 5")
chk((2 * _x + 0).subs(_x, 3) == 6, "演習6 a = 0 なら 6（段ができる）")
_a6 = -1

# 7 IVT で根の存在
_e7 = _x ** 3 + 2 * _x - 5
chk(_e7.subs(_x, 1) == -2 and _e7.subs(_x, 2) == 7, "演習7 端の値は -2 と 7")
chk(_e7.subs(_x, 1) < 0 < _e7.subs(_x, 2), "演習7 0 はそのあいだ")
chk(s4(_e7, "1.3", "%.3f") == "-0.203", "演習7 f(1.3) = -0.203")
chk(s4(_e7, "1.4", "%.3f") == "0.544", "演習7 f(1.4) = 0.544")
chk(1.3 < float(sp.nsolve(_e7, 1.35)) < 1.4, "演習7 根は 1.3 と 1.4 のあいだ")
_a7 = "root in (1,2)"

# 8 IVT の 3 つの問い
chk(-3 < 0 < 5, "演習8 0 は -3 と 5 のあいだ")
# (c) の反例: 値が 5 と -3 しかない関数は 0 を取らない
chk(0 not in (5, -3), "演習8 反例は 0 を取らない")
# (b) の例: 5 → -1 → 2 → -3 は x 軸を 3 回またぐ
_seq = [5, -1, 2, -3]
_cross = sum(1 for _i in range(3) if _seq[_i] * _seq[_i + 1] < 0)
chk(_cross == 3, "演習8 その例は 3 回またぐ")
_a8 = "IVT (a)(b)(c)"

# 9 k = 8
_e9 = (_x ** 2 - 16) / (_x - 4)
eq(sp.factor(_x ** 2 - 16), (_x + 4) * (_x - 4), "演習9 因数分解")
chk(sp.limit(_e9, _x, 4) == 8, "演習9 極限は 8")
chk(s4(_x + 4, "3.999", "%.3f") == "7.999" and s4(_x + 4, "4.001", "%.3f") == "8.001",
    "演習9 両側の値")
# ★ k を変えても極限は 8 のまま（だから k = 5 でも removable）
chk(sp.limit(_e9, _x, 4) == 8 and 8 != 5, "演習9 k = 5 でも極限は 8")
_a9 = 8

# 10 vertical asymptote（removable ではない）
_e10 = 1 / (_x - 2)
chk(sp.limit(_e10, _x, 2, "+") == sp.oo, "演習10 右から +∞")
chk(sp.limit(_e10, _x, 2, "-") == -sp.oo, "演習10 左から -∞")
chk(s4(_e10, "2.01", "%.1f") == "100.0" and s4(_e10, "1.99", "%.1f") == "-100.0",
    "演習10 x = 2.01, 1.99 の値")
chk(s4(_e10, "2.001", "%.1f") == "1000.0" and s4(_e10, "1.999", "%.1f") == "-1000.0",
    "演習10 x = 2.001, 1.999 の値")
chk(sp.gcd(sp.Integer(1), _x - 2) == 1, "演習10 分子と分母に共通の因数がない")
_a10 = "vertical asymptote"

_ans = [_a1, _a2, _a3, _a4, _a5, _a6, _a7, _a8, _a9, _a10]
chk(len(set(map(str, _ans))) == len(_ans), "演習の答えが重複していない: %s" % (_ans,))

# ══════════════════════════════════════════════════════════
# 本文が例題・演習の答えを先に見せていないこと
# ══════════════════════════════════════════════════════════
_body = TEXT[:TEXT.index("\n## Worked examples")]
for _leak in ("x^{2}-9", "x^{2}-16", "x^{2}-5x+4", "x^{3}+2x-5", "2x+a",
              "= 8$", "= 6$", "k = 3", "a = -1", "x^{2}+3x-10"):
    chk(_leak not in _body, "本文が答えを先に見せている: " + _leak)
# ══════════════════════════════════════════════════════════
# 構成
# ══════════════════════════════════════════════════════════
_tips = re.findall(r"::: \{\.callout-tip collapse=\"true\"\}\n## (.+)", TEXT)
_gdc = [h for h in _tips
        if not h.startswith("解説") and h != "クリックすると開きます"]
chk(len(_gdc) == 1, "電卓の折りたたみは 1 つ: %s" % _gdc)
for _h in _gdc:
    chk(_h.startswith("Section I Part B と Section II Part A では"),
        "電卓の見出しが Section I Part B で始まる: " + _h)
chk("## Using your GDC" not in TEXT, "独立した GDC の節は置いていない")
in_text("**Section I Part A と Section II Part B では使えません。**",
        "電卓が使えない区分を明記")
for _m in ["Casio", "fx-CG50", "TI-84", "OPTN", "PRB", "cSolve", "nDeriv"]:
    not_in_text(_m, "他機種・確かめていない機能: " + _m)
for _m in ["Paper 1", "Paper 2", "IB ", "GDC"]:
    not_in_text(_m, "IB の言いまわしが残っている: " + _m)
not_in_text("## 参考：この項目のシラバス（原文）", "末尾のシラバスは置かない")
# ★ 決めごと（_AP-BC-PLAN.md）: dx は斜体、逆三角は \arctan
not_in_text("\\mathrm{d}", "dx は斜体に統一（\\mathrm{d} を使わない）")
not_in_text("\\tan^{-1}", "逆三角関数は \\arctan に統一")
chk(len([l for l in TEXT.splitlines() if l.rstrip() == "---"]) == 6, "--- は 6 本")
chk(TEXT.count('<details class="jp-trans">') == 14, "日本語訳が 14")
chk(TEXT.count("</details>") == 14, "</details> も 14")
chk(TEXT.count("{.ex-sep}") == 9, "ex-sep が 9")
chk(TEXT.count("{.ex-no}") == 10, "演習が 10")
chk(TEXT.count("{.model-answer}") == 4, "model-answer が 4")
chk(len(re.findall(r"^::: \{#exm-apbc13-", TEXT, re.M)) == 4, "例題が 4")
chk(TEXT.count("## 解答例（答案用紙に書くこと）") == 14, "解答例が 14")
_h2 = re.findall(r"^## (.+)$", TEXT, re.M)
_want = ["The idea", "Why it works", "Worked examples", "Common errors",
         "Exercises"]
chk([h for h in _h2 if h in _want] == _want, "5 つの見出しが所定の順")
_nums = [int(_v) for _v in re.findall(r"^### (\d+)\. ", TEXT, re.M)]
chk(_nums == list(range(1, len(_nums) + 1)) and 5 <= len(_nums) <= 7,
    "The idea が 1.. の連番（5〜7 節）: %s" % _nums)
chk(TEXT.count("**検算") >= 12, "検算が十分ある: %d" % TEXT.count("**検算"))
not_in_text("**確かめ", "検算は「検算」で統一")
for word in ["誰でもできる", "簡単です", "当然", "明らか", "もちろん",
             "当たり前", "そのとおり"]:
    not_in_text(word, "禁止語")
_ce = TEXT[TEXT.index("\n## Common errors"):TEXT.index("\n## Exercises")]
chk(_ce.count("::: {.callout-warning}") == 6, "Common errors が 6 つ")
# ★ AP の答案作法（引き継ぎ §6.3）を Common errors に必ず 1 つ入れる
chk(("Justify" in _ce or "Explain" in _ce)
    and ("単位" in _ce or "途中の式" in _ce or "根拠" in _ce),
    "Common errors に AP の答案作法がある")
_MASKED = TEXT.replace("\\$", "")
for _blk in re.findall(r"\$\$(.*?)\$\$", _MASKED, re.S):
    chk("✓" not in _blk and "✗" not in _blk, "表示数式に ✓/✗: " + _blk[:40])
for _blk in re.findall(r"(?<!\$)\$([^$\n]+)\$(?!\$)", _MASKED):
    chk("✓" not in _blk and "✗" not in _blk, "インライン数式に ✓/✗: " + _blk[:40])
chk(all("@eq-" not in TEXT.split("$$")[i] for i in range(1, len(TEXT.split("$$")), 2)),
    "表示数式の中に @-ref がない")
for _blk in re.findall(r"::: \{\.model-answer\}(.*?):::", TEXT, re.S):
    chk(not re.search(r"[ぁ-んァ-ン一-龥]",
                      _blk.replace("**試験ではこう書く**", "")),
        "model-answer に日本語")
_anchors = set(re.findall(r"\{#([a-z0-9-]+)\}", TEXT))
for _a0 in set(re.findall(r"\]\(#([a-z0-9-]+)\)", TEXT)):
    chk(_a0 in _anchors or _a0 in {"why-it-works", "common-errors", "exercises"},
        "ページ内リンク先がない: #" + _a0)
for _r0 in set(re.findall(r"@(?:exm|eq|fig|tbl)-([a-z0-9]+)-", TEXT)):
    chk(_r0 == "apbc13", "他ページの @-ref: " + _r0)
for _href in re.findall(r"\]\(([^)]+\.qmd[^)]*)\)", TEXT):
    chk(os.path.exists(os.path.normpath(os.path.join(
        os.path.dirname(QMD), _href.split("#")[0]))),
        "リンク先のページがない: " + _href)
_head = TEXT[:TEXT.index("## The idea")]
chk(_head.count("::: {.callout-note}") == 1 and _head.count(":::") == 2,
    "冒頭の callout は 1 つだけ")
not_in_text("**この節ですること：", "節の頭の 1 文は置かない")
not_in_text("\\vec{", "ベクトルの記号は太字")
chk(len(re.findall(r"^::: ", TEXT, re.M)) == len(re.findall(r"^:::$", TEXT, re.M)),
    "::: の開閉が一致")
for _h in re.findall(r"^#{1,4} .+$", TEXT, re.M):
    chk(not re.search(r"\$\s*—", _h), "見出しで数式の直後に —: " + _h)
_i = TEXT.index(chr(10) + "## Why it works" + chr(10))
_j = TEXT.index(chr(10) + "## Worked examples", _i)
_wiw = TEXT[_i:_j]
chk('collapse="true"}' + chr(10) + "## クリックすると開きます" in _wiw,
    "Why it works は折りたたんである")
chk(_wiw.rstrip().endswith(":::"), "折りたたみが閉じてある")
# ★ The idea の見出しは「英語（日本語）」の形
for _hh in re.findall(r"^### \d+\. (.+?) \{#", TEXT, re.M):
    chk(_hh.endswith("）") and "（" in _hh,
        "見出しが 英語（日本語） の形でない: " + _hh)
    chk(re.match(r"[A-Za-z$]", _hh) is not None,
        "見出しが英語で始まっていない: " + _hh)
    _en = _hh[:_hh.rindex("（")]
    chk(not re.search(r"[ぁ-んァ-ヶ一-龥]", _en),
        "見出しの英語の側に日本語がある: " + _hh)

# ══════════════════════════════════════════════════════════
# 図
# ══════════════════════════════════════════════════════════
for _n in ("a", "b"):
    _p = os.path.join(BASE, "img", "apbc-1-3-idea-%s.svg" % _n)
    chk(os.path.exists(_p), "図 (%s) がある" % _n)
    chk("](img/apbc-1-3-idea-%s.svg)" % _n in TEXT,
        "本文が図 (%s) を貼っている" % _n)
for _s0 in glob.glob(os.path.join(BASE, "img", "*.png")):
    chk(False, "PNG が残っている: " + os.path.basename(_s0))
for bad in ["pmatrix", "\\lvert", "\\rvert"]:
    chk(bad not in FIGCODE, "図で使えない記法: " + bad)
chk(not re.search(r"[ぁ-んァ-ン]", FIGSTR), "図のラベルに日本語がない")
# ★ ここに、このページ固有の図の検査を書いてください。
#    図の見出しとラベルを in_fig で逐語に押さえ、図の数値が本文と
#    合っていること、図が例題・演習の答えを載せていないことを見ます。
#    見本: figs/ap-bc/check_apbc_1_3.py

# ══════════════════════════════════════════════════════════
# 登録
# ══════════════════════════════════════════════════════════
DRAFT = open(os.path.join(ROOT, "_quarto-draft.yml"), encoding="utf-8").read()
chk("ap-bc/01-limits/apbc-1-3.qmd" in DRAFT, "draft に登録")
PUB = open(os.path.join(ROOT, "_quarto.yml"), encoding="utf-8").read()
chk("ap-bc" not in PUB, "公開用には入れない")
chk("G-LQBB7M9VZ0" not in PUB, "IB の本の測定 ID を流用していない")
IDX = open(os.path.join(ROOT, "ap-bc", "index.qmd"), encoding="utf-8").read()
chk("(01-limits/apbc-1-3.qmd)" in IDX, "index にある")
_written = sorted(glob.glob(os.path.join(ROOT, "ap-bc", "*", "apbc-*.qmd")))
chk(len(re.findall(r"^\| \*\*Unit [0-9.]+\*\* \|.*✅", IDX, re.M)) == len(_written),
    "✅ の数とページ数が合う")
_mm = re.search(r"いまのところ (\d+) ページです（全 (\d+) ページ）", IDX)
chk(_mm is not None and int(_mm.group(1)) == len(_written), "「いまのところ N」")
chk(_mm is not None and int(_mm.group(2)) == 45, "全 45 ページ")
_rows = re.findall(r"^\| \*\*Unit [0-9.]+\*\* \|", IDX, re.M)
chk(len(_rows) == 45, "一覧表の行が 45: %d" % len(_rows))
PLAN = open(os.path.join(ROOT, "_AP-BC-PLAN.md"), encoding="utf-8").read()
_pm = re.search(r"\*\*進捗：(\d+) / 45 ページ。\*\*", PLAN)
chk(_pm is not None and int(_pm.group(1)) == len(_written), "PLAN の進捗")
GLO = open(os.path.join(ROOT, "glossary-ap.qmd"), encoding="utf-8").read()
for t in ["| limit |", "| one-sided limit |", "| left-hand limit |",
          "| right-hand limit |", "| does not exist |", "| indeterminate form |",
          "| average rate of change |", "| instantaneous rate of change |"]:
    chk(t in GLO, "対訳表にある: " + t)
# ★ .gitignore が College Board の PDF を止めているか
GI = open(os.path.join(ROOT, ".gitignore"), encoding="utf-8").read()
chk(re.search(r"^\*\.pdf$", GI, re.M) is not None, ".gitignore に *.pdf がある")


# ══════════════════════════════════════════════════════════
# ページ固有: CED の逐語引用と、見張り
# ══════════════════════════════════════════════════════════
in_text("**このページが扱う CED Topic：1.10・1.11・1.12・1.13・1.16**", "CED Topic の明記")
not_in_text("**BC only**", "このページは BC 限定ではない")

in_text("> A function $f$ is continuous at $x = c$ provided that $f(c)$ exists, "
        "$\\lim_{x \\to c} f(x)$ exists, and $\\lim_{x \\to c} f(x) = f(c)$",
        "CED LIM-2.A.2（連続の定義）")
in_text("> Types of discontinuities include removable discontinuities, jump "
        "discontinuities, and discontinuities due to vertical asymptotes.",
        "CED LIM-2.A.1（不連続の種類）")
in_text("> Polynomial, rational, power, exponential, logarithmic, and "
        "trigonometric functions are continuous on all points in their domains.",
        "CED LIM-2.B.2")
in_text("> A function is continuous on an interval if the function is continuous "
        "at each point in the interval.", "CED LIM-2.B.1")
in_text("> If the limit of a function exists at a discontinuity in its graph, "
        "then it is possible to remove the discontinuity", "CED LIM-2.C.1")
in_text("> In order for a piecewise-defined function to be continuous at a "
        "boundary to the partition of its domain", "CED LIM-2.C.2")
in_text("> If $f$ is a continuous function on the closed interval $[a, b]$ and "
        "$d$ is a number between $f(a)$ and $f(b)$, then the Intermediate Value "
        "Theorem guarantees that there is at least one number $c$ between $a$ "
        "and $b$, such that $f(c) = d$.", "CED FUN-1.A.1（IVT）")

# 言い切りの見張り
in_text("**$3$ つとも確かめてください。**", "3 条件を全部見る")
in_text("**removable だけは「直せます」**", "removable だけ直せる")
in_text("**「少なくとも $1$ つ」です。**", "at least one")
in_text("*at least one* $c$ と書いてください", "答案での書き方")
not_in_text("ちょうど $1$ つあります", "IVT で個数を断定していない")
in_text("Unit 1.1 第 7 節](apbc-1-1.qmd#value)", "Unit 1.1 へのリンク")
in_text("Unit 1.1 第 4 節](apbc-1-1.qmd#graph)", "Unit 1.1 へのリンク")
_prev = open(os.path.join(BASE, "apbc-1-1.qmd"), encoding="utf-8").read()
chk("{#value}" in _prev and "{#graph}" in _prev, "リンク先のアンカーがある")
chk("### 7. " in _prev and "### 4. " in _prev, "リンク先の節番号がある")
not_in_text("](apbc-1-4.qmd", "まだ無いページにリンクしていない")

# ══════════════════════════════════════════════════════════
# 図
# ══════════════════════════════════════════════════════════
in_fig("three types of discontinuity", "図 (a) の見出し")
for _w in ("removable", "jump", "vertical asymptote"):
    in_fig('"%s"' % _w, "図 (a) のパネル: " + _w)
in_fig("the limit exists,\\nbut the point is missing", "図 (a) removable の説明")
in_fig("the two sides\\ngo to different heights", "図 (a) jump の説明")
in_fig("the values become\\nunbounded", "図 (a) asymptote の説明")
in_fig("a continuous graph cannot skip a height between $f(a)$ and $f(b)$",
       "図 (b) の見出し")
in_fig("$d$ is between $f(a)$ and $f(b)$, so $f(c) = d$", "図 (b) の説明")
# ★ 図 (b) は d をまたぐ曲線を 1 本だけ描いている（c が 1 つに見えること）
chk("idx = np.where(np.diff(np.sign(y - d)))[0]" in FIGCODE, "図 (b) は交点を計算している")
# ★ 図が例題・演習の答えを載せていないこと
for _leak in ("= 8", "= 7", "1/6", "-1", "k ="):
    chk(_leak not in FIGSTR, "図のラベルが答えを載せている: " + _leak)

# ══════════════════════════════════════════════════════════
# 用語集（このページで初出の語）
# ══════════════════════════════════════════════════════════
for t in ["| continuous |", "| removable discontinuity |", "| jump discontinuity |",
          "| vertical asymptote |", "| Intermediate Value Theorem |",
          "| closed interval |"]:
    chk(t in GLO, "対訳表にある: " + t)

print()
print("OK", OK, "/ NG", NG)
sys.exit(1 if NG else 0)
