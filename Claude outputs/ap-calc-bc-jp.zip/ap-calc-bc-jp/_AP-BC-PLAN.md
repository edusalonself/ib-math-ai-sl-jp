# AP Calculus BC — ページ一覧（執筆計画）

College Board の **AP Calculus AB and BC Course and Exam Description（CED、Effective Fall 2020）**
の Unit 1〜10（およそ $111$ Topic）を、**45 ページ**に分けて書きます。

**進捗：4 / 45 ページ。**

- **$1$ ページに CED Topic を $2$〜$5$ つ**まとめます。
- **Unit 9・10 は BC だけの単元**で、比重が合わせて $25$〜$35\%$ あります。
  ここは厚めに取り、$13$ ページ（全体の $29\%$）を当てました。
- ページ番号は「Unit N の M ページ目」という意味で、**CED の Topic 番号とは別物**です。
  各ページの冒頭 callout に、扱う CED Topic の番号を書きます。

## 決まったこと（2026-09-21、Early に確認）

1. **総ページ数は 45。** 割り当ては下の表のとおり。
2. **ファイル名・題名・アンカー**は次の形。
   | もの | 形 | 例 |
   |:--|:--|:--|
   | ファイル | `ap-bc/<unit>/apbc-N-M.qmd` | `ap-bc/01-limits/apbc-1-1.qmd` |
   | 題名 | `# Unit N.M — English title（日本語）` | |
   | 題名のアンカー | `{#sec-apbc-N-M}` | `{#sec-apbc-1-1}` |
   | 式・図・表 | `eq-apbcNM-…` / `fig-apbcNM-…` / `tbl-apbcNM-…` | `@fig-apbc11-idea-a` |
   | 図のスクリプト | `figs/ap-bc/make_apbc_N_M.py` | |
   | チェッカー | `figs/ap-bc/check_apbc_N_M.py` | |
   | 図の出力 | `ap-bc/<unit>/img/apbc-N-M-idea-a.svg` | |
3. **$dx$ は斜体**（`dx`、`\frac{dy}{dx}`）。CED の表記に合わせます。`\mathrm{d}x` は使いません。
4. **逆三角関数は `\arctan`** に統一。初出で「$\tan^{-1}x$ とも書きます」と $1$ 行だけ添えます。
5. **BC だけの内容には、冒頭 callout の中に $1$ 行だけ印**を置きます。
   ```
   - **BC only** — AB では扱いません。
   ```
   ページの一部だけが BC のときは、その節の見出しの直後に同じ $1$ 行を置きます。
6. **AA HL（IB の本）へのリンクは張りません。** 別サイトなので外部リンクになり、
   `tools/check_refs.py` が見張れないためです。

## ページの形

`ib-math-ai-sl-jp/_AA-START-HERE.md` 第 3 節と `_方針変更-2026-09-15.md`（第 1〜18 節）に
従います。食い違うときは後者が優先です。AP に固有の決めごとは
`_AP-CALC-BC-引き継ぎ-2026-09-21.md` の §6 にあります。

```
# Unit N.M — English title（日本語） {#sec-apbc-N-M}

::: {.callout-note}
## What you should be able to do
:::

## The idea            ### 1.〜 7.（見出しは English（日本語）、{#anchor} を手書き）
## Why it works        ::: {.callout-tip collapse="true"} ## クリックすると開きます
## Worked examples     例題 4
## Common errors       callout-warning 6 つ
## Exercises           演習 10（8・9・10 に {.model-answer}）
```

電卓の話は、本文中に `::: {.callout-tip collapse="true"}` を $1$ つだけ置き、
見出しを **`## Section I Part B と Section II Part A では、電卓が使えます`** で始めます。
独立した `## Using your GDC` の節は作りません。

## ページの割り当て

| Unit | 内容 | 比重 | ページ数 | CED Topic 数 |
|:--|:--|:--|:--|:--|
| 1 | Limits and Continuity | 5–10% | 4 | 16 |
| 2 | Differentiation: Definition and Fundamental Properties | 5–10% | 3 | 10 |
| 3 | Differentiation: Composite, Implicit, and Inverse Functions | 5–10% | 3 | 6 |
| 4 | Contextual Applications of Differentiation | 5–10% | 3 | 7 |
| 5 | Analytical Applications of Differentiation | 10–15% | 4 | 12 |
| 6 | Integration and Accumulation of Change | 15–20% | 7 | 14 |
| 7 | Differential Equations | 5–10% | 3 | 9 |
| 8 | Applications of Integration | 5–10% | 5 | 13 |
| 9 | Parametric, Polar, Vector-Valued（BC のみ） | 10–15% | 5 | 9 |
| 10 | Infinite Sequences and Series（BC のみ） | 15–20% | 8 | 15 |
| | **合計** | | **45** | **111** |

ページごとの題名と CED Topic の対応は、`ap-bc/index.qmd` の一覧表にあります。
**その表が正**です。書きながら分け方を変えたときは、両方を直してください。

## 書く順番

Unit 1 から順に書きます。$1$ ページ書き終えるごとに Early に見せます。

## $1$ ページを書く手順

1. **CED の該当 Topic を原文で読む**（Learning Objective / Essential Knowledge）
2. **例題・演習の数値を sympy で全部作る**
3. **図を作って、PNG に落として目で見る**（見たら PNG を消す）
4. **本文を書く**
5. **チェッカー `figs/ap-bc/check_apbc_N_M.py` を書いて NG 0 にする**
6. `python3 tools/check_refs.py`
7. `node tools/mathcheck.js <そのページ>`（$1$ ファイルずつ。0 failed）
8. `node tools/mathwidth.js <そのページ>`（700px 超え 0）
9. `quarto render <そのページ> --profile draft`（error/warning なし）
10. `_quarto-draft.yml` / `ap-bc/index.qmd` / `glossary-ap.qmd` / この PLAN を更新

## まだ決めていないこと

- **`_quarto.yml` の `site-url`**（公開先の URL）
- **Google アナリティクスの測定 ID**（IB の本のものは流用しない。入るまで
  `google-analytics` と `cookie-consent` はコメントのまま）

★ **試験の形は、CED の Exam Information で裏を取って `ap-bc/index.qmd` に書きました**
（2026-09-21）。CED の PDF はリポジトリ直下にあります（`.gitignore` の `*.pdf` で
除外済み。**コミットしないこと**）。
