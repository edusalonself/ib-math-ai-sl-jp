# -*- coding: utf-8 -*-
"""書き上がったページを、_quarto-draft.yml / ap-bc/index.qmd / _AP-BC-PLAN.md に登録する。

    python3 tools/reg_apbc.py <stem> <dir> "<sidebar text>" "<unit section>"

例:
    python3 tools/reg_apbc.py apbc-1-2 01-limits \\
        "Unit 1.2 — Finding limits algebraically and the squeeze theorem" \\
        "Unit 1 — Limits and Continuity"

★ ap-bc/index.qmd の一覧表に、そのページの行が **すでにある**ことが前提です
   （`| **Unit 1.2** | 題名 | CED | | — |` の形）。行の題名をリンクに変え、
   いちばん右の欄を ✅ にします。題名は、その行から読み取ります。

★ 公開用の _quarto.yml はさわりません。公開は Early が手で行います。
"""
import glob
import os
import re
import sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
stem, d, sidebar, section = sys.argv[1:5]
num = re.sub(r"^apbc-(\d+)-(\d+)$", r"\1.\2", stem)      # apbc-1-2 -> 1.2
label = "Unit " + num

# ── 1) _quarto-draft.yml（下書きのサイドバー）────────────────
p = os.path.join(ROOT, "_quarto-draft.yml")
t = open(p, encoding="utf-8").read()
entry = ('            - file: ap-bc/%s/%s.qmd\n              text: "%s"\n'
         % (d, stem, sidebar))
if entry not in t:
    sec = '        - section: "%s"\n          contents:\n' % section
    if sec in t:
        i = t.index(sec) + len(sec)
        while t[i:i + 12] == "            ":              # その節の末尾まで送る
            i = t.index("\n", t.index("\n", i) + 1) + 1
        t = t[:i] + entry + t[i:]
    else:                                                 # 新しい Unit の節を作る
        t = t.rstrip("\n") + "\n\n" + sec + entry
    open(p, "w", encoding="utf-8").write(t)

# ── 2) ap-bc/index.qmd（一覧・進捗）──────────────────────────
p = os.path.join(ROOT, "ap-bc", "index.qmd")
t = open(p, encoding="utf-8").read()

row = re.search(r"^\| \*\*%s\*\* \|.*\|$" % re.escape(label), t, re.M)
assert row is not None, "index.qmd に行がありません: " + label
cells = [c.strip() for c in row.group(0).strip().strip("|").split("|")]
assert len(cells) == 5, "一覧表の列が 5 つではありません: " + row.group(0)
title, ced, bc = cells[1], cells[2], cells[3]
if "](" not in title:                                     # まだリンクになっていない
    new_row = "| **%s** | [%s](%s/%s.qmd) | %s | %s | ✅ |" % (
        label, title, d, stem, ced, bc)
    t = t[:row.start()] + new_row + t[row.end():]
    link = "- [%s — %s](%s/%s.qmd)\n" % (label, title.split("（")[0], d, stem)
    if link not in t:
        mark = "\n**いまのところ"
        t = t.replace(mark, link + mark, 1)

written = len(glob.glob(os.path.join(ROOT, "ap-bc", "*", "apbc-*.qmd")))
t = re.sub(r"いまのところ \d+ ページです", "いまのところ %d ページです" % written, t)
open(p, "w", encoding="utf-8").write(t)

# ── 3) _AP-BC-PLAN.md（進捗）────────────────────────────────
p = os.path.join(ROOT, "_AP-BC-PLAN.md")
t = open(p, encoding="utf-8").read()
t = re.sub(r"\*\*進捗：\d+ / 45 ページ。\*\*", "**進捗：%d / 45 ページ。**" % written, t)
open(p, "w", encoding="utf-8").write(t)

print("registered:", stem, "->", written, "/ 45 pages")
